#!/usr/bin/env python3
"""Private, dependency-free proof for the 2026-10-21 HASI screenshot batch."""
from __future__ import annotations
import argparse, binascii, hashlib, json, math, os, shutil, struct, subprocess, sys, tempfile, zlib
from collections import Counter
from pathlib import Path

ATTACHMENT_ROOT = Path('/Users/fabian/.codex/attachments/hasi-contrast-current-20261021')
CAL_JSON = 'color-calibration-13.json'
CAL_PNG = 'color-calibration-13.png'
CONTROL_JSON = 'painted-color-sensitive-controls-measurement.json'
EXPECTED_HEX = ['#ff0000','#00ff00','#0000ff','#ffffff','#000000','#808080','#111311','#686d66','#494e48','#b9c0b3','#ecdcd4','#f8f6f0','#abc398']
EXPECTED_CSS = ['rgb(255, 0, 0)','rgb(0, 255, 0)','rgb(0, 0, 255)','rgb(255, 255, 255)','rgb(0, 0, 0)','rgb(128, 128, 128)','rgb(17, 19, 17)','rgb(104, 109, 102)','rgb(73, 78, 72)','rgb(185, 192, 179)','rgb(236, 220, 212)','rgb(248, 246, 240)','rgb(171, 195, 152)']
# WCAG 2.2 relative-luminance coefficients for CSS sRGB foregrounds / sRGB interpretation.
W_SRGB = (0.2126, 0.7152, 0.0722)
# CSS Color 4's D65 Display-P3 Y row (exact rational coefficients).
W_P3 = (35783/156275, 247089/357200, 198249/2500400)
# Exact rational CSS Color 4 matrices for sRGB -> XYZ D65 -> Display-P3.
M_SRGB_XYZ = ((506752/1228815,87881/245763,12673/70218),(87098/409605,175762/245763,12673/175545),(7918/409605,87881/737289,1001167/1053270))
M_XYZ_P3 = ((446124/178915,-333277/357830,-72051/178915),(-14852/17905,63121/35810,423/17905),(11844/330415,-50337/660830,316169/330415))
PNG_SIG = b'\x89PNG\r\n\x1a\n'

class ProofError(Exception): pass

def read_png(path):
    data = Path(path).read_bytes()
    if not data.startswith(PNG_SIG): raise ProofError(f'{path}: bad PNG signature')
    pos=8; chunks=[]; idats=[]; ihdr=None
    while pos < len(data):
        if pos+12 > len(data): raise ProofError(f'{path}: truncated chunk')
        n=struct.unpack('>I',data[pos:pos+4])[0]
        kind=data[pos+4:pos+8]
        end=pos+12+n
        if end > len(data): raise ProofError(f'{path}: truncated {kind!r}')
        chunk=data[pos+8:pos+8+n]
        crc=struct.unpack('>I',data[pos+8+n:end])[0]
        if (binascii.crc32(kind+chunk)&0xffffffff) != crc: raise ProofError(f'{path}: CRC mismatch in {kind!r}')
        chunks.append(kind.decode('ascii'))
        if kind==b'IHDR':
            if ihdr is not None or n!=13: raise ProofError(f'{path}: invalid IHDR')
            ihdr=struct.unpack('>IIBBBBB',chunk)
        elif kind==b'IDAT': idats.append(chunk)
        elif kind==b'IEND':
            if n!=0: raise ProofError(f'{path}: invalid IEND')
            pos=end
            break
        pos=end
    if pos!=len(data): raise ProofError(f'{path}: trailing data after IEND')
    if ihdr is None: raise ProofError(f'{path}: missing IHDR')
    w,h,depth,ctype,comp,flt,interlace=ihdr
    channels={0:1,2:3,4:2,6:4}.get(ctype)
    if channels is None or depth!=8 or comp!=0 or flt!=0 or interlace!=0: raise ProofError(f'{path}: unsupported PNG layout {ihdr}')
    try: raw=zlib.decompress(b''.join(idats))
    except zlib.error as e: raise ProofError(f'{path}: invalid PNG image stream: {e}')
    stride=w*channels
    if len(raw)!=h*(stride+1): raise ProofError(f'{path}: decompressed size mismatch')
    rows=[]; previous=bytearray(stride); at=0
    def paeth(a,b,c):
        p=a+b-c; pa=abs(p-a); pb=abs(p-b); pc=abs(p-c)
        return a if pa<=pb and pa<=pc else (b if pb<=pc else c)
    for _ in range(h):
        filt=raw[at]; at+=1; scan=bytearray(raw[at:at+stride]); at+=stride
        for i in range(stride):
            a=scan[i-channels] if i>=channels else 0; b=previous[i]; c=previous[i-channels] if i>=channels else 0
            if filt==1: scan[i]=(scan[i]+a)&255
            elif filt==2: scan[i]=(scan[i]+b)&255
            elif filt==3: scan[i]=(scan[i]+((a+b)//2))&255
            elif filt==4: scan[i]=(scan[i]+paeth(a,b,c))&255
            elif filt!=0: raise ProofError(f'{path}: invalid PNG filter {filt}')
        rows.append(scan); previous=scan
    pixels=[]
    for row in rows:
        out=[]
        for x in range(w):
            vals=tuple(row[x*channels:(x+1)*channels])
            if ctype in (0,4): rgb=(vals[0],)*3; alpha=vals[1] if ctype==4 else 255
            else: rgb=vals[:3]; alpha=vals[3] if ctype==6 else 255
            if alpha!=255: raise ProofError(f'{path}: non-opaque pixel')
            out.append(rgb)
        pixels.append(out)
    return {'width':w,'height':h,'depth':depth,'colorType':ctype,'chunks':chunks,'pixels':pixels}

def parse_rgb(value):
    import re
    m=re.fullmatch(r'rgb\((\d+), (\d+), (\d+)\)', value or '')
    if not m: raise ProofError(f'unsupported/non-integer CSS RGB value: {value!r}')
    rgb=tuple(int(x) for x in m.groups())
    if any(c<0 or c>255 for c in rgb): raise ProofError(f'out-of-range CSS RGB value: {value!r}')
    return rgb

def lin(c):
    v=c/255
    return v/12.92 if v<=0.04045 else ((v+0.055)/1.055)**2.4

def enc(v): return 12.92*v if v<=0.0031308 else 1.055*(v**(1/2.4))-0.055

def matvec(M,v): return tuple(sum(row[i]*v[i] for i in range(3)) for row in M)

def predicted_p3(rgb):
    xyz=matvec(M_SRGB_XYZ,tuple(lin(c) for c in rgb))
    p3=matvec(M_XYZ_P3,xyz)
    encoded=tuple(255*enc(c) for c in p3)
    if any(c < -1e-8 or c > 255+1e-8 for c in encoded): raise ProofError(f'calibration color outside P3 gamut: {rgb}')
    rounded=tuple(math.floor(c+0.5) for c in encoded)
    return rounded,encoded

def validate_calibration(root):
    root=Path(root)
    try: meta=json.loads((root/CAL_JSON).read_text())
    except Exception as e: raise ProofError(f'malformed calibration JSON: {e}')
    if meta.get('colors')!=EXPECTED_HEX: raise ProofError('calibration source color sequence differs from fixed 13-color protocol')
    metrics=meta.get('metrics')
    if not isinstance(metrics,dict) or metrics.get('css')!=EXPECTED_CSS: raise ProofError('calibration CSS-source sequence differs from fixed protocol')
    rect=metrics.get('rect')
    if rect!={'bottom':220,'height':20,'left':20,'right':280,'top':200,'width':260,'x':20,'y':200}: raise ProofError('calibration CSS rectangle differs from expected explicit clip')
    if metrics.get('scrollX')!=0 or metrics.get('scrollY')!=0: raise ProofError('calibration page scroll is not zero')
    if meta.get('clip')!={'x':20,'y':200,'width':260,'height':20,'scale':1}: raise ProofError('calibration clip metadata differs from expected 260x20 CSS-pixel clip')
    im=read_png(root/CAL_PNG)
    if (im['width'],im['height'],im['depth'],im['colorType'])!=(260,20,8,2): raise ProofError('calibration PNG must be untagged 260x20 8-bit RGB')
    if len(im['chunks'])<3 or im['chunks'][0]!='IHDR' or im['chunks'][-1]!='IEND' or any(x!='IDAT' for x in im['chunks'][1:-1]): raise ProofError(f'calibration PNG has unexpected ancillary/profile chunks: {im["chunks"]}')
    patches=[]; max_error=0.0
    for i,(hexv,css) in enumerate(zip(EXPECTED_HEX,EXPECTED_CSS)):
        src=tuple(int(hexv[j:j+2],16) for j in (1,3,5))
        if parse_rgb(css)!=src: raise ProofError(f'calibration hex/CSS mismatch at patch {i}')
        expected,encoded=predicted_p3(src)
        patch=[im['pixels'][y][x] for y in range(20) for x in range(i*20,(i+1)*20)]
        counts=Counter(patch)
        if len(counts)!=1 or next(iter(counts))!=expected: raise ProofError(f'patch {i} pixels do not equal rounded sRGB-to-P3 prediction {expected}; observed {counts.most_common(3)}')
        err=max(abs(float(a)-float(b)) for a,b in zip(expected,encoded))
        max_error=max(max_error,err)
        patches.append({'css':css,'source_srgb':src,'observed_p3_bytes':expected,'pixels':len(patch),'unique_colors':len(counts),'max_rounding_residual_code_values':err})
    return {'status':'valid','model':'CSS Color 4 sRGB transfer + exact sRGB-D65 to XYZ to Display-P3 matrices; 8-bit nearest rounding','patch_count':13,'pixels_per_patch':400,'total_pixels':5200,'max_rounding_residual_code_values':max_error,'max_observed_rounding_interval':0.5,'quantization_assumption':'conventional nearest-integer quantization of each encoded 8-bit Display-P3 channel; each observed code represents [code-0.5, code+0.5] clipped to [0,255]','png_chunks':im['chunks'],'patches':patches}

def Y(rgb, weights): return sum(lin(c)*w for c,w in zip(rgb,weights))
def y_interval(rgb,weights):
    low=[]; high=[]
    for c in rgb:
        a=max(0.0,(c-0.5)/255); b=min(1.0,(c+0.5)/255)
        low.append(a/12.92 if a<=0.04045 else ((a+0.055)/1.055)**2.4)
        high.append(b/12.92 if b<=0.04045 else ((b+0.055)/1.055)**2.4)
    return sum(w*x for w,x in zip(weights,low)),sum(w*x for w,x in zip(weights,high))

def ratio(a,b): return (max(a,b)+0.05)/(min(a,b)+0.05)

def case_guard(row, root):
    reasons=[]
    if row.get('before')!=row.get('after'): reasons.append('layout changed during capture')
    if row.get('after')!=row.get('restored'): reasons.append('layout differs after restoration')
    if row.get('leaves')!=row.get('restoredLeaves'): reasons.append('leaf state differs after restoration')
    if row.get('originalInlineStyle')!=row.get('restoredInlineStyle'): reasons.append('inline style differs after restoration')
    mask=row.get('maskSelector'); sel=row.get('selector','')
    if not isinstance(mask,str) or not mask or not (sel==mask or (sel.startswith(mask) and (len(sel)==len(mask) or sel[len(mask)] in ' >+~'))): reasons.append('mask selector is not the target or a selector prefix for an ancestor')
    leaves=row.get('leaves')
    if not isinstance(leaves,list) or not leaves: reasons.append('missing leaves')
    else:
        for li,leaf in enumerate(leaves):
            if leaf.get('textFill')!=leaf.get('color'): reasons.append(f'leaf {li}: textFill differs from computed color')
            if leaf.get('textShadow')!='none': reasons.append(f'leaf {li}: text shadow is not none')
            if not leaf.get('text'): reasons.append(f'leaf {li}: no text')
            if any(not h.get('withinTarget') or not h.get('withinTextParent') for h in leaf.get('hits',[])): reasons.append(f'leaf {li}: hit test outside target/text parent')
            if not leaf.get('hits'): reasons.append(f'leaf {li}: missing hit-test evidence')
            for anc in leaf.get('ancestors',[]):
                if anc.get('opacity')!='1' or anc.get('blend')!='normal' or anc.get('filter')!='none' or anc.get('maskImage')!='none': reasons.append(f'leaf {li}: ancestor compositing changes color')
                if not str(anc.get('backgroundClip','')).startswith('border-box'): reasons.append(f'leaf {li}: unexpected background clip')
    clips=row.get('clips')
    if not isinstance(clips,list) or not clips: reasons.append('missing clipped background PNGs')
    else:
        for ci,entry in enumerate(clips):
            li=entry.get('leaf'); ri=entry.get('rect'); clip=entry.get('clip')
            if not isinstance(li,int) or not isinstance(ri,int) or not isinstance(clip,dict) or li>=len(leaves or []) or ri>=len((leaves or [{}])[li].get('rects',[])):
                reasons.append(f'clip {ci}: invalid leaf/rect reference'); continue
            rect=leaves[li]['rects'][ri]
            try:
                ex=math.floor(rect['left']); ey=math.floor(rect['top']); er=math.ceil(rect['right']); eb=math.ceil(rect['bottom'])
                if (clip.get('x'),clip.get('y'),clip.get('width'),clip.get('height'),clip.get('scale'))!=(ex,ey,er-ex,eb-ey,1): reasons.append(f'clip {ci}: explicit CSS clip differs from floor/ceil text rect')
            except Exception: reasons.append(f'clip {ci}: malformed geometry')
            file=entry.get('file','')
            if Path(file).name!=file: reasons.append(f'clip {ci}: non-local file reference'); continue
            try: im=read_png(root/file)
            except Exception as e: reasons.append(f'clip {ci}: {e}'); continue
            if (im['width'],im['height'])!=(clip.get('width'),clip.get('height')): reasons.append(f'clip {ci}: PNG dimensions do not match explicit clip')
    return sorted(set(reasons))

def measure_row(row, root, calibration, profile, validate_painted_controls=False):
    reasons=case_guard(row,root)
    try: fg=parse_rgb(row['leaves'][0]['textFill'])
    except Exception as e: raise ProofError(f'{row.get("selector")}: {e}')
    threshold=float(row['threshold']); fy=Y(fg,W_SRGB)
    weights=W_P3 if profile=='p3' else W_SRGB
    pixels=[]; clip_details=[]
    for ent in row['clips']:
        im=read_png(root/ent['file']); pix=[v for line in im['pixels'] for v in line]
        pixels.extend(pix)
        clip_details.append({'file':ent['file'],'clip':ent['clip'],'dimensions':[im['width'],im['height']],'unique_colors':{str(k):v for k,v in sorted(Counter(pix).items())}})
    if validate_painted_controls:
        source=row.get('originalInlineStyle','')
        import re
        m=re.search(r'background: (rgb\(\d+, \d+, \d+\)); color: (rgb\(\d+, \d+, \d+\));',source)
        if not m: raise ProofError(f'{row["selector"]}: cannot bind inline CSS background/foreground')
        bg=parse_rgb(m.group(1)); inline_fg=parse_rgb(m.group(2))
        if inline_fg!=fg: raise ProofError(f'{row["selector"]}: inline foreground differs from captured textFill')
        pred,_=predicted_p3(bg)
        for pix in pixels:
            if pix!=pred: raise ProofError(f'{row["selector"]}: captured background pixel {pix} differs from calibrated P3 {pred} for CSS {bg}')
        calibration_patch={tuple(p['observed_p3_bytes']):p for p in calibration['patches']}
        if pred not in calibration_patch: raise ProofError(f'{row["selector"]}: source color is not a calibrated patch')
    point=[]; lower=[]; upper=[]
    for bg in pixels:
        by=Y(bg,weights); point.append(ratio(fy,by))
        lo,hi=y_interval(bg,weights)
        lowratio=min(ratio(fy,lo),ratio(fy,hi)); highratio=max(ratio(fy,lo),ratio(fy,hi))
        lower.append(lowratio); upper.append(highratio)
    return {'selector':row['selector'],'threshold':threshold,'foreground_css_srgb':fg,'pixel_count':len(pixels),'minimum_ratio_point':min(point),'minimum_ratio_quantization_lower_bound':min(lower),'maximum_ratio_quantization_upper_bound':max(upper),'conservative_pass':not reasons and min(lower)>=threshold,'point_pass':min(point)>=threshold,'guard_status':'valid' if not reasons else 'invalid','guard_errors':reasons,'clips':clip_details}

def load_rows(root,name):
    try: rows=json.loads((root/name).read_text())
    except Exception as e: raise ProofError(f'malformed measurement {name}: {e}')
    if not isinstance(rows,list): raise ProofError(f'{name}: expected list')
    return rows

def find_row(rows, selector):
    matches=[r for r in rows if r.get('selector')==selector]
    if len(matches)!=1: raise ProofError(f'expected one row for {selector}, found {len(matches)}')
    return matches[0]

CONTROL_SELECTORS={'red-positive':'#hasi-color-srgb-red-pass','blue-negative':'#hasi-color-srgb-blue-fail'}

def evaluate_control(root, case, profile):
    calibration=validate_calibration(root)
    rows=load_rows(root,CONTROL_JSON)
    row=find_row(rows,CONTROL_SELECTORS[case])
    result=measure_row(row,root,calibration,profile,True)
    if result['guard_status']!='valid': raise ProofError(f'{case}: capture guards invalid: {result["guard_errors"]}')
    return result

def sha(path):
    b=Path(path).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def file_manifest(root,names):
    return {name:sha(root/name) for name in sorted(set(names))}

def collect_batch(root, calibration):
    named=[]; file_names={CAL_JSON,CAL_PNG,CONTROL_JSON}
    controls=load_rows(root,CONTROL_JSON)
    for row in controls:
        for ent in row['clips']: file_names.add(ent['file'])
        named.append({'batch':'sensitive_controls','row':row,'profile_results':{p:measure_row(row,root,calibration,p,True) for p in ('p3','srgb')}})
    for mode in ('light','dark'):
        name=f'painted-welcome-{mode}-candidate-measurement.json'; file_names.add(name)
        rows=load_rows(root,name)
        if len(rows)!=15: raise ProofError(f'{name}: expected 15 candidate rows')
        for row in rows:
            for ent in row['clips']: file_names.add(ent['file'])
            named.append({'batch':f'welcome_{mode}_candidate','row':row,'profile_results':{p:measure_row(row,root,calibration,p) for p in ('p3','srgb')}})
    admin_passes=[]
    for i in range(23):
        name=f'admin-painted-dark-pair-{i}-measurement.json'; file_names.add(name)
        rows=load_rows(root,name)
        if len(rows)!=1: raise ProofError(f'{name}: expected one case')
        row=rows[0]
        for ent in row['clips']: file_names.add(ent['file'])
        measured={p:measure_row(row,root,calibration,p) for p in ('p3','srgb')}
        named.append({'batch':'admin_painted_dark','index':i,'row':row,'profile_results':measured})
        if i!=10 and measured['p3']['conservative_pass'] and measured['srgb']['conservative_pass']: admin_passes.append(i)
    # Reduce stored full rows to compact summaries after hashes are collected.
    compact=[]
    for entry in named:
        row=entry.pop('row')
        compact.append({**entry,'selector':row['selector'],'threshold':row['threshold']})
    manifest=file_manifest(root,file_names)
    return compact,manifest,file_names

def make_png_rgb(pixels):
    h=len(pixels);w=len(pixels[0]);raw=b''.join(b'\x00'+bytes(c for rgb in row for c in rgb) for row in pixels)
    def chunk(kind,data): return struct.pack('>I',len(data))+kind+data+struct.pack('>I',binascii.crc32(kind+data)&0xffffffff)
    ihdr=struct.pack('>IIBBBBB',w,h,8,2,0,0,0)
    return PNG_SIG+chunk(b'IHDR',ihdr)+chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b'')

def run_negative_calibration_tests(root):
    temp=Path(tempfile.mkdtemp(prefix='hasi-color-calibration-isolated-',dir='/private/tmp'))
    results=[]
    srcjson=json.loads((root/CAL_JSON).read_text());srcpng=read_png(root/CAL_PNG)
    malformed=temp/'malformed';malformed.mkdir()
    shutil.copy2(root/CAL_PNG,malformed/CAL_PNG)
    (malformed/CAL_JSON).write_text('{"colors": [')
    p=subprocess.run([sys.executable,__file__,'validate-calibration','--root',str(malformed)],capture_output=True,text=True)
    results.append({'fixture':'malformed JSON in isolated copy','exit_code':p.returncode,'rejected':p.returncode==2,'output':(p.stderr or p.stdout).strip()})
    wrong=temp/'wrong';wrong.mkdir();shutil.copy2(root/CAL_JSON,wrong/CAL_JSON)
    pixels=[[tuple(px) for px in row] for row in srcpng['pixels']]
    r,g,b=pixels[0][0];pixels[0][0]=(r+1,g,b)
    (wrong/CAL_PNG).write_bytes(make_png_rgb(pixels))
    p=subprocess.run([sys.executable,__file__,'validate-calibration','--root',str(wrong)],capture_output=True,text=True)
    results.append({'fixture':'valid PNG with one altered calibration pixel in isolated copy','exit_code':p.returncode,'rejected':p.returncode==2,'output':(p.stderr or p.stdout).strip()})
    return {'isolated_temp_directory':str(temp),'tests':results,'all_rejected':all(x['rejected'] for x in results)}

def build_proof(root):
    cal=validate_calibration(root)
    controls={case:{profile:evaluate_control(root,case,profile) for profile in ('p3','srgb')} for case in CONTROL_SELECTORS for _ in [0]}
    expected={'red-positive':{'p3':0,'srgb':1},'blue-negative':{'p3':1,'srgb':0}}
    # Exercise the user's requested command-line contract, not only internal booleans.
    exit_checks=[]
    for case in CONTROL_SELECTORS:
        for profile,expected_code in expected[case].items():
            p=subprocess.run([sys.executable,__file__,'evaluate-control','--root',str(root),'--case',case,'--profile',profile],capture_output=True,text=True)
            exit_checks.append({'case':case,'profile':profile,'exit_code':p.returncode,'expected_exit_code':expected_code,'matches_expected':p.returncode==expected_code,'stdout':p.stdout.strip()})
    compact,manifest,files=collect_batch(root,cal)
    # Determine robust named candidate counts under calibrated P3 and deliberately wrong sRGB.
    batches={}
    for e in compact:
        if e['batch']=='sensitive_controls': continue
        b=e['batch']; v=batches.setdefault(b,{'count':0,'evaluable_count':0,'excluded_known_range_cases':[],'p3_robust_pass':0,'evaluable_p3_robust_pass':0,'srgb_robust_pass':0,'p3_failures':[],'sRGB_p3_classification_flips':[],'minimum_p3_margin_over_threshold':None})
        p3=e['profile_results']['p3'];s=e['profile_results']['srgb'];v['count']+=1
        excluded=(b=='admin_painted_dark' and e.get('index')==10)
        if excluded:
            v['excluded_known_range_cases'].append({'index':10,'selector':e['selector'],'reason':'Range extends beyond the ellipsized ancestor and samples unrelated background; parent-provided capture investigation note'})
        else: v['evaluable_count']+=1
        if p3['conservative_pass']:
            v['p3_robust_pass']+=1
            if not excluded: v['evaluable_p3_robust_pass']+=1
        else: v['p3_failures'].append({'index':e.get('index'),'selector':e['selector'],'threshold':e['threshold'],'min_ratio_lower':p3['minimum_ratio_quantization_lower_bound'],'guard_errors':p3['guard_errors']})
        if s['conservative_pass'] and not excluded: v['srgb_robust_pass']+=1
        if p3['conservative_pass']!=s['conservative_pass']: v['sRGB_p3_classification_flips'].append({'index':e.get('index'),'selector':e['selector'],'p3':p3['conservative_pass'],'srgb':s['conservative_pass']})
        if p3['guard_status']=='valid' and not excluded:
            margin=p3['minimum_ratio_quantization_lower_bound']-e['threshold']
            if v['minimum_p3_margin_over_threshold'] is None or margin<v['minimum_p3_margin_over_threshold']: v['minimum_p3_margin_over_threshold']=margin
    proof={
      'title':'Batch-specific screenshot color calibration and contrast proof',
      'scope':{'attachment_batch':root.name,'capture_scope':'Only the named explicit CSS-clip captures in this attachment batch, using their recorded CSS-pixel clip coordinates and scale 1. The evidence does not establish a universal profile for other browsers, operating systems, screenshot APIs, or future captures.','profile_claim':'The 13 same-path known CSS patches are exactly the rounded sRGB-to-Display-P3 encoding predictions. This validates a Display-P3 interpretation for this batch/capture path, without claiming the untagged PNGs carry a formal ICC profile.','browser_version_viewport':'Not recorded in the supplied JSON; do not generalize by browser/version/viewport.'},
      'calibration':cal,
      'sensitive_text_control_matrix':{'cases':controls,'expected_exit_codes':expected,'exit_checks':exit_checks,'all_exit_checks_match':all(x['matches_expected'] for x in exit_checks)},
      'candidate_batch_counts':batches,
      'named_candidate_measurements':compact,
      'admin_outlier_disposition':{'index':10,'selector':'.profile-copy > strong','contrast_result':'fails 4.5 threshold in the supplied Range-derived clip','decision':'exclude from UI defect/pass count because the supplied Range extends beyond its ellipsized ancestor and includes unrelated background; treat as invalid background region evidence, not as a passing contrast case','source':'parent-provided capture investigation notes'},
      'input_manifest':manifest,
      'input_count':len(manifest),
      'integrity_tests':run_negative_calibration_tests(root),
      'decision_rule':'Accept a named contrast case only if its actual capture guards validate and its minimum WCAG contrast ratio remains at or above its recorded threshold across every clipped background pixel after applying the per-channel encoded-code interval [byte-0.5, byte+0.5]. For CSS foregrounds, use exact computed sRGB bytes; decode captured backgrounds as Display-P3 based on the same-path 13-patch calibration.'
    }
    proof['proof_pass']=proof['sensitive_text_control_matrix']['all_exit_checks_match'] and proof['integrity_tests']['all_rejected'] and all(v['p3_robust_pass']==v['count'] for k,v in batches.items() if k.startswith('welcome_')) and batches['admin_painted_dark']['evaluable_p3_robust_pass']==22 and batches['admin_painted_dark']['evaluable_count']==22
    return proof

def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='cmd',required=True)
    v=sub.add_parser('validate-calibration');v.add_argument('--root',type=Path,default=ATTACHMENT_ROOT)
    e=sub.add_parser('evaluate-control');e.add_argument('--root',type=Path,default=ATTACHMENT_ROOT);e.add_argument('--case',choices=CONTROL_SELECTORS,required=True);e.add_argument('--profile',choices=('p3','srgb'),required=True)
    b=sub.add_parser('prove');b.add_argument('--root',type=Path,default=ATTACHMENT_ROOT);b.add_argument('--out',type=Path,default=Path('/private/tmp/hasi-color-calibration-proof.json'))
    args=ap.parse_args()
    try:
        if args.cmd=='validate-calibration':
            out=validate_calibration(args.root);print(json.dumps(out,indent=2));return 0
        if args.cmd=='evaluate-control':
            out=evaluate_control(args.root,args.case,args.profile);print(json.dumps(out,indent=2));return 0 if out['conservative_pass'] else 1
        proof=build_proof(args.root)
        args.out.write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
        print(json.dumps({'proof_file':str(args.out),'proof_pass':proof['proof_pass'],'input_count':proof['input_count'],'candidate_batch_counts':proof['candidate_batch_counts'],'sensitive_text_control_matrix':proof['sensitive_text_control_matrix'],'integrity_tests':proof['integrity_tests']},indent=2))
        return 0 if proof['proof_pass'] else 1
    except Exception as e:
        print(f'proof rejected: {e}',file=sys.stderr);return 2

if __name__=='__main__': raise SystemExit(main())
