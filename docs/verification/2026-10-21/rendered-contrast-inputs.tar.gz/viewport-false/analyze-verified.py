#!/usr/bin/env python3
"""Independent verifier for the bounded HASI viewport-false contrast batch."""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import math
import re
import tempfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
MEASURE_SOURCE = ROOT / "measure-source.js"
CAPTURE_FACTORY = ROOT / "capture-factory.js"
HELPER_PATH = PARENT / "png-color-helper.py"

spec = importlib.util.spec_from_file_location("hasi_color", HELPER_PATH)
color = importlib.util.module_from_spec(spec)
spec.loader.exec_module(color)


class Reject(Exception):
    pass


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def require(ok: bool, reason: str, errors: list[str]) -> None:
    if not ok:
        errors.append(reason)


def expected_threshold(leaf: dict) -> float:
    size = float(str(leaf["fontSize"]).removesuffix("px"))
    weight = float(leaf["fontWeight"])
    return 3.0 if size >= 24 or (size >= 18.667 and weight >= 700) else 4.5


def geometry(record: dict) -> dict:
    leaves = record.get("leaves", [])
    return {
        "target": record.get("target"),
        "scroll": record.get("scroll"),
        "ancestors": [leaf.get("ancestors") for leaf in leaves],
        "regions": [[{
            "raw": region.get("raw"),
            "visible": region.get("visible"),
            "hits": region.get("hits"),
            "clip": region.get("clip"),
        } for region in leaf.get("regions", [])] for leaf in leaves],
    }


def lower_ratio(foreground_y: float, low: float, high: float) -> float:
    # Include the interior minimum when the quantization interval crosses the
    # foreground luminance; endpoint-only minima would not be a true lower bound.
    if low <= foreground_y <= high:
        return 1.0
    return min(color.ratio(foreground_y, low), color.ratio(foreground_y, high))


def profile_scores(foreground_rgb: tuple[int, int, int], pixels: list[tuple[int, int, int]], weights: tuple[float, float, float]) -> dict:
    foreground_y = color.Y(foreground_rgb, color.W_SRGB)
    point = []
    lower = []
    for rgb in pixels:
        background_y = color.Y(rgb, weights)
        point.append(color.ratio(foreground_y, background_y))
        low, high = color.y_interval(rgb, weights)
        lower.append(lower_ratio(foreground_y, low, high))
    return {
        "minimum_point_ratio": min(point),
        "minimum_quantization_lower_bound": min(lower),
        "pixel_count": len(pixels),
    }


def verify_record(record: dict, filename: str, root: Path, measure_sha: str,
                  png_overrides: dict[str, Path] | None = None) -> tuple[list[str], list[dict], int]:
    errors: list[str] = []
    png_overrides = png_overrides or {}
    req = lambda ok, why: require(bool(ok), why, errors)

    protocol = record.get("protocol", {})
    req(protocol.get("tabId") == "24", f"{filename}: unexpected tab id")
    req(protocol.get("method") == "Page.captureScreenshot", f"{filename}: unexpected capture API")
    req(protocol.get("captureBeyondViewport") is False, f"{filename}: captureBeyondViewport was not false")
    req(protocol.get("sourceSha256") == measure_sha, f"{filename}: measurement source hash mismatch")
    req(record.get("viewport") == {"dpr": 1, "height": 900, "width": 1280},
        f"{filename}: unexpected viewport")
    req(record.get("url", "").startswith("https://hasi.metaneutrons.cc/"),
        f"{filename}: unexpected page origin")

    leaves = record.get("leaves")
    if not isinstance(leaves, list) or not leaves:
        return errors + [f"{filename}: missing text leaves"], [], 0
    req(record.get("target") is not None and record.get("scroll") is not None,
        f"{filename}: missing target or scroll")
    req(len(record.get("maskedFills", [])) == len(leaves),
        f"{filename}: mask fill count differs from text leaves")
    req(all(fill == "rgba(0, 0, 0, 0)" for fill in record.get("maskedFills", [])),
        f"{filename}: one or more text leaves remained visible under mask")

    initial = record.get("initial", {})
    restored_original = record.get("originalRestoration", {})
    req(restored_original.get("scroll") == initial.get("scroll"),
        f"{filename}: original root scroll was not restored")
    req(restored_original.get("parents") == initial.get("parents"),
        f"{filename}: original ancestor scroll/style state was not restored")
    req(restored_original.get("maskAbsent") is True,
        f"{filename}: temporary mask remained after restoration")
    restored = record.get("restored", {})
    req(restored.get("target") == record.get("target"),
        f"{filename}: target geometry changed after mask removal")
    req(restored.get("scroll") == record.get("scroll"),
        f"{filename}: observed root scroll changed after mask removal")
    cleaned = copy.deepcopy(leaves)
    for leaf in cleaned:
        for region in leaf.get("regions", []):
            region.pop("file", None)
            region.pop("sha256", None)
    req(cleaned == restored.get("leaves"),
        f"{filename}: leaf styles/geometry changed after mask removal")

    expected_files = []
    leaf_metrics: list[dict] = []
    total_images = 0
    theme_match = re.match(r"^app-(?:chat|admin|welcome)-(light|dark)-", filename)
    if theme_match:
        req(initial.get("theme") == theme_match.group(1),
            f"{filename}: recorded theme differs from filename")

    for li, leaf in enumerate(leaves):
        try:
            fg = color.parse_rgb(leaf.get("fill"))
        except Exception as exc:
            errors.append(f"{filename}: leaf {li}: unsupported foreground: {exc}")
            continue
        req(leaf.get("fill") == leaf.get("color"),
            f"{filename}: leaf {li}: text fill differs from CSS color")
        req(leaf.get("textShadow") == "none",
            f"{filename}: leaf {li}: text shadow is not none")
        try:
            threshold = expected_threshold(leaf)
            req(float(leaf.get("threshold")) == threshold,
                f"{filename}: leaf {li}: stored threshold does not match computed font threshold")
        except Exception as exc:
            errors.append(f"{filename}: leaf {li}: invalid font threshold data: {exc}")
            threshold = float(leaf.get("threshold", 4.5))

        for ai, ancestor in enumerate(leaf.get("ancestors", [])):
            for key, expected in (("opacity", "1"), ("filter", "none"),
                                  ("blend", "normal"), ("clipPath", "none"),
                                  ("clip", "auto"), ("maskImage", "none")):
                req(ancestor.get(key) == expected,
                    f"{filename}: leaf {li}: ancestor {ai} {key}={ancestor.get(key)!r}")
            req("paint" not in str(ancestor.get("contain", "")),
                f"{filename}: leaf {li}: ancestor {ai} uses paint containment")

        all_pixels: list[tuple[int, int, int]] = []
        for ri, region in enumerate(leaf.get("regions", [])):
            total_images += 1
            file = region.get("file", "")
            expected_files.append(file)
            req(isinstance(file, str) and Path(file).name == file,
                f"{filename}: leaf {li} region {ri}: nonlocal image path")
            if not isinstance(file, str) or Path(file).name != file:
                continue

            visible = region.get("visible", {})
            clip = region.get("clip", {})
            scroll = record.get("scroll", {})
            try:
                x0 = math.floor(visible["left"])
                y0 = math.floor(visible["top"])
                x1 = math.ceil(visible["right"])
                y1 = math.ceil(visible["bottom"])
                expected_clip = {
                    "x": x0 + scroll["x"],
                    "y": y0 + scroll["y"],
                    "width": x1 - x0,
                    "height": y1 - y0,
                    "scale": 1,
                }
                req(clip == expected_clip,
                    f"{filename}: leaf {li} region {ri}: clip does not enclose the visible text rect")
            except Exception as exc:
                errors.append(f"{filename}: leaf {li} region {ri}: malformed visible/clip geometry: {exc}")

            hits = region.get("hits", [])
            req(len(hits) == 9 and all(hit.get("withinTextParent") is True for hit in hits),
                f"{filename}: leaf {li} region {ri}: incomplete hit-test grid")
            try:
                for hit in hits:
                    req(visible["left"] <= hit["x"] <= visible["right"] and
                        visible["top"] <= hit["y"] <= visible["bottom"],
                        f"{filename}: leaf {li} region {ri}: hit point outside visible rect")
            except Exception as exc:
                errors.append(f"{filename}: leaf {li} region {ri}: malformed hit point: {exc}")

            check = None
            checks = record.get("imageChecks", [])
            if ri == 0 and li == 0:
                pass
            for item in checks:
                if item.get("file") == file:
                    check = item
                    break
            req(check is not None, f"{filename}: image check missing for {file}")
            if check is not None:
                req(check.get("args") == {
                    "format": "png",
                    "captureBeyondViewport": False,
                    "clip": clip,
                }, f"{filename}: capture arguments differ from recorded clip for {file}")
                req(check.get("after") == geometry(record),
                    f"{filename}: target/scroll/ancestor/clip geometry changed during capture of {file}")

            path = png_overrides.get(file, root / file)
            try:
                data = path.read_bytes()
            except Exception as exc:
                errors.append(f"{filename}: cannot read {file}: {exc}")
                continue
            req(sha_bytes(data) == region.get("sha256"),
                f"{filename}: PNG hash mismatch for {file}")
            try:
                image = color.read_png(path)
            except Exception as exc:
                errors.append(f"{filename}: invalid PNG {file}: {exc}")
                continue
            req((image["width"], image["height"]) == (clip.get("width"), clip.get("height")),
                f"{filename}: PNG dimensions do not match clip for {file}")
            all_pixels.extend(tuple(rgb) for row in image["pixels"] for rgb in row)

        leaf_metrics.append({
            "leaf_index": li,
            "text": leaf.get("text", ""),
            "font_size": leaf.get("fontSize"),
            "font_weight": leaf.get("fontWeight"),
            "threshold": threshold,
            "foreground_css_srgb": fg,
            "profile_p3": profile_scores(fg, all_pixels, color.W_P3) if all_pixels else None,
            "profile_srgb": profile_scores(fg, all_pixels, color.W_SRGB) if all_pixels else None,
            "pass": bool(all_pixels) and profile_scores(fg, all_pixels, color.W_P3)["minimum_quantization_lower_bound"] >= threshold,
            "background_palette": [{"rgb": rgb, "count": count} for rgb, count in sorted(Counter(all_pixels).items())],
        })

    check_files = [item.get("file") for item in record.get("imageChecks", [])]
    req(check_files == expected_files,
        f"{filename}: image-check order/count differs from measured regions")
    req(len(record.get("imageChecks", [])) == total_images,
        f"{filename}: image-check count differs from measured regions")

    return errors, leaf_metrics, total_images


def calibrate(root: Path) -> dict:
    errors: list[str] = []
    meta = json.loads((root / "calibration.json").read_text())
    proof = json.loads((root / "calibration-proof.json").read_text())
    expected_hex = meta["setup"]["colors"]
    require(len(expected_hex) == 13, "calibration must declare 13 CSS colors", errors)
    require(len(meta.get("captures", [])) == 2, "calibration must contain two captures", errors)
    require(len(proof) == 2, "calibration proof must contain two capture entries", errors)
    proof_by_file = {x["file"]: x for x in proof}
    capture_results = []
    digest_list = []
    for entry in meta.get("captures", []):
        filename = entry["file"]
        before = entry["before"]
        after = entry["after"]
        rect = before["rect"]
        scroll = before["scroll"]
        require(after.get("rect") == rect and after.get("scroll") == scroll,
                f"{filename}: calibration state changed during capture", errors)
        args = entry["args"]
        expected_args = {
            "format": "png",
            "captureBeyondViewport": False,
            "clip": {
                "x": rect["left"] + scroll["x"],
                "y": rect["top"] + scroll["y"],
                "width": rect["width"],
                "height": rect["height"],
                "scale": 1,
            },
        }
        require(args == expected_args, f"{filename}: calibration clip args mismatch", errors)
        path = root / filename
        data = path.read_bytes()
        digest = sha_bytes(data)
        digest_list.append(digest)
        p = proof_by_file.get(filename, {})
        require(p.get("sha256") == digest, f"{filename}: calibration proof hash mismatch", errors)
        require(p.get("stable") is True and p.get("patches") == 13 and p.get("quadrants") == 4,
                f"{filename}: calibration proof summary mismatch", errors)
        image = color.read_png(path)
        require((image["width"], image["height"], image["depth"], image["colorType"]) == (260, 100, 8, 2),
                f"{filename}: calibration must be 260x100 8-bit RGB", errors)
        patch_details = []
        pixels_checked = 0
        for i, hex_color in enumerate(expected_hex):
            rgb = tuple(int(hex_color[j:j + 2], 16) for j in (1, 3, 5))
            expected = color.predicted_p3(rgb)[0]
            patch = [image["pixels"][y][x]
                     for y in range(20) for x in range(i * 20, (i + 1) * 20)]
            require(all(value == expected for value in patch),
                    f"{filename}: top patch {i} differs from predicted P3 {expected}", errors)
            pixels_checked += len(patch)
            patch_details.append({"css_srgb": hex_color, "observed_p3": expected, "pixels": len(patch)})
        quadrant_details = []
        for i, hex_color in enumerate(expected_hex[:4]):
            rgb = tuple(int(hex_color[j:j + 2], 16) for j in (1, 3, 5))
            expected = color.predicted_p3(rgb)[0]
            x0, x1 = (i % 2) * 130, (i % 2 + 1) * 130
            y0, y1 = 20 + (i // 2) * 40, 20 + (i // 2 + 1) * 40
            quadrant = [image["pixels"][y][x] for y in range(y0, y1) for x in range(x0, x1)]
            require(all(value == expected for value in quadrant),
                    f"{filename}: quadrant {i} differs from predicted P3 {expected}", errors)
            pixels_checked += len(quadrant)
            quadrant_details.append({"css_srgb": hex_color, "observed_p3": expected, "pixels": len(quadrant)})
        capture_results.append({
            "file": filename,
            "sha256": digest,
            "scroll": scroll,
            "clip": args["clip"],
            "pixels_checked": pixels_checked,
            "top_patches": patch_details,
            "bottom_quadrants": quadrant_details,
        })
    require(len(set(digest_list)) == 1, "calibration captures differ across scroll positions", errors)
    return {"errors": errors, "captures": capture_results, "same_digest": len(set(digest_list)) == 1}


def control_source_colors(record: dict) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    style = record["initial"]["parents"][0]["style"]
    background = re.search(r"background:\s*rgb\((\d+),\s*(\d+),\s*(\d+)\)", style)
    foreground = re.search(r"color:\s*rgb\((\d+),\s*(\d+),\s*(\d+)\)", style)
    if not background or not foreground:
        raise Reject("control inline style does not bind CSS background and foreground")
    return tuple(map(int, background.groups())), tuple(map(int, foreground.groups()))


def verify_control(record: dict, filename: str, root: Path, measure_sha: str,
                   calibration: dict) -> dict:
    errors, leaves, images = verify_record(record, filename, root, measure_sha)
    if errors:
        raise Reject("; ".join(errors[:5]))
    bg_css, fg_css = control_source_colors(record)
    leaf = leaves[0]
    require = lambda ok, why: (_ for _ in ()).throw(Reject(why)) if not ok else None
    require(tuple(leaf["foreground_css_srgb"]) == fg_css, f"{filename}: CSS foreground mismatch")
    expected_p3 = color.predicted_p3(bg_css)[0]
    require(tuple(bg_css) in [tuple(int(h[j:j + 2], 16) for j in (1, 3, 5))
                              for h in json.loads((root / "calibration.json").read_text())["setup"]["colors"]],
            f"{filename}: CSS background is not a calibration patch")
    require(all(tuple(px) == expected_p3 for item in leaf["background_palette"]
                for px in [item["rgb"]]), f"{filename}: image pixels do not match calibrated P3 background")
    p3 = leaf["profile_p3"]["minimum_quantization_lower_bound"]
    srgb = leaf["profile_srgb"]["minimum_quantization_lower_bound"]
    return {
        "file": filename,
        "css_background_srgb": bg_css,
        "css_foreground_srgb": fg_css,
        "observed_background_p3": expected_p3,
        "threshold": leaf["threshold"],
        "p3_lower_bound": p3,
        "p3_pass": p3 >= leaf["threshold"],
        "wrong_srgb_lower_bound": srgb,
        "wrong_srgb_pass": srgb >= leaf["threshold"],
        "image_count": images,
    }


def run_negative_probes(root: Path, measure_sha: str, sample: dict, sample_name: str) -> dict:
    results = []

    altered = copy.deepcopy(sample)
    old = float(altered["leaves"][0]["threshold"])
    altered["leaves"][0]["threshold"] = old + 0.5
    errors, _, _ = verify_record(altered, sample_name + " [threshold tamper]", root, measure_sha)
    results.append({
        "probe": "font threshold tamper",
        "rejected": any("threshold does not match" in e for e in errors),
        "reasons": errors[:3],
    })

    altered = copy.deepcopy(sample)
    altered["imageChecks"][0]["after"]["scroll"]["y"] += 1
    errors, _, _ = verify_record(altered, sample_name + " [scroll tamper]", root, measure_sha)
    results.append({
        "probe": "per-image scroll geometry tamper",
        "rejected": any("geometry changed during capture" in e for e in errors),
        "reasons": errors[:3],
    })

    altered = copy.deepcopy(sample)
    region = altered["leaves"][0]["regions"][0]
    filename = region["file"]
    png_bytes = bytearray((root / filename).read_bytes())
    png_bytes[-1] ^= 1  # Flip one bit in the PNG IEND CRC.
    region["sha256"] = sha_bytes(bytes(png_bytes))
    with tempfile.TemporaryDirectory(prefix="hasi-vf-corrupt-") as td:
        corrupt_path = Path(td) / filename
        corrupt_path.write_bytes(png_bytes)
        errors, _, _ = verify_record(
            altered, sample_name + " [PNG byte tamper]", root, measure_sha,
            png_overrides={filename: corrupt_path},
        )
    results.append({
        "probe": "one-byte PNG CRC tamper with matching updated hash",
        "rejected": any("CRC mismatch" in e for e in errors),
        "reasons": errors[:3],
    })
    return {"probes": results, "all_rejected": all(x["rejected"] for x in results)}


def main() -> int:
    root = ROOT
    measure_sha = sha_file(MEASURE_SOURCE)
    factory_sha = sha_file(CAPTURE_FACTORY)
    helper_sha = sha_file(HELPER_PATH)
    calibration = calibrate(root)

    app_paths = sorted(list(root.glob("app-chat-*.json")) +
                       list(root.glob("app-admin-*.json")) +
                       list(root.glob("app-welcome-*.json")))
    expected_counts = {
        "app-chat": 24,
        "app-admin": 26,
        "app-welcome": 22,
    }
    count_by_family = {name: len(list(root.glob(name + "-*.json"))) for name in expected_counts}
    top_errors = list(calibration["errors"])
    for family, expected in expected_counts.items():
        if count_by_family[family] != expected:
            top_errors.append(f"{family}: expected {expected} groups, observed {count_by_family[family]}")
    if len(app_paths) != 72:
        top_errors.append(f"app group count expected 72, observed {len(app_paths)}")

    all_groups = []
    pair_records: dict[str, dict[str, dict]] = {}
    normal_leaves = []
    large_leaves = []
    image_total = 0
    for path in app_paths:
        record = json.loads(path.read_text())
        errors, leaves, image_count = verify_record(record, path.name, root, measure_sha)
        image_total += image_count
        group = {
            "file": path.name,
            "theme": record.get("initial", {}).get("theme"),
            "capture_valid": not errors,
            "capture_errors": errors,
            "leaf_count": len(leaves),
            "png_count": image_count,
            "leaves": leaves,
            "contrast_pass": not errors and all(leaf["pass"] for leaf in leaves),
        }
        all_groups.append(group)
        for leaf in leaves:
            target = large_leaves if leaf["threshold"] == 3 else normal_leaves
            target.append({"file": path.name, **leaf})
        match = re.match(r"^app-(chat|admin|welcome)-(light|dark)-(.+)\.json$", path.name)
        if match:
            family, theme, component = match.groups()
            key = f"{family}-{component}"
            pair_records.setdefault(key, {})[theme] = group
        else:
            top_errors.append(f"{path.name}: cannot derive theme pair key")

    all_pairs = []
    for key, themes in sorted(pair_records.items()):
        light = themes.get("light")
        dark = themes.get("dark")
        complete = light is not None and dark is not None
        fail_themes = []
        if light is not None and not light["contrast_pass"]:
            fail_themes.append("light")
        if dark is not None and not dark["contrast_pass"]:
            fail_themes.append("dark")
        all_pairs.append({
            "pair": key,
            "complete": complete,
            "light": None if light is None else {
                "file": light["file"], "capture_valid": light["capture_valid"],
                "contrast_pass": light["contrast_pass"],
                "minimum": min((x["profile_p3"]["minimum_quantization_lower_bound"]
                                for x in light["leaves"] if x.get("profile_p3")), default=None),
            },
            "dark": None if dark is None else {
                "file": dark["file"], "capture_valid": dark["capture_valid"],
                "contrast_pass": dark["contrast_pass"],
                "minimum": min((x["profile_p3"]["minimum_quantization_lower_bound"]
                                for x in dark["leaves"] if x.get("profile_p3")), default=None),
            },
            "failing_themes": fail_themes,
        })
        if not complete:
            top_errors.append(f"{key}: missing light or dark pair member")

    control_results = {}
    for name in ("control-pass.json", "control-fail.json"):
        record = json.loads((root / name).read_text())
        control_results[name] = verify_control(record, name, root, measure_sha, calibration)

    diagnostic_name = "diagnostic-current-dark-proposal-time.json"
    diagnostic_record = json.loads((root / diagnostic_name).read_text())
    diagnostic_errors, diagnostic_leaves, diagnostic_images = verify_record(
        diagnostic_record, diagnostic_name, root, measure_sha)
    diagnostic = {
        "file": diagnostic_name,
        "capture_valid": not diagnostic_errors,
        "capture_errors": diagnostic_errors,
        "leaf_count": len(diagnostic_leaves),
        "png_count": diagnostic_images,
        "leaves": diagnostic_leaves,
    }

    sample_path = next((p for p in app_paths if p.name == "app-chat-light-proposal-time.json"), app_paths[0])
    sample = json.loads(sample_path.read_text())
    probes = run_negative_probes(root, measure_sha, sample, sample_path.name)

    all_pngs = sorted({r["file"] for g in all_groups for leaf in g["leaves"]
                       for r in json.loads((root / g["file"]).read_text())["leaves"][leaf["leaf_index"]]["regions"]})
    source_manifest = {
        "measure-source.js": {"sha256": measure_sha, "bytes": MEASURE_SOURCE.stat().st_size},
        "capture-factory.js": {"sha256": factory_sha, "bytes": CAPTURE_FACTORY.stat().st_size},
        "png-color-helper.py": {"sha256": helper_sha, "bytes": HELPER_PATH.stat().st_size},
    }
    used = {
        "calibration.json", "calibration-proof.json", "cal-0.png", "cal-200.png",
        "control-pass.json", "control-fail.json", "diagnostic-current-dark-proposal-time.json",
        diagnostic_name,
    }
    used.update(path.name for path in app_paths)
    used.update(all_pngs)
    for name in ("control-pass.json", "control-fail.json", diagnostic_name):
        record = json.loads((root / name).read_text())
        for leaf in record["leaves"]:
            for region in leaf["regions"]:
                used.add(region["file"])
    input_manifest = {name: {"bytes": (root / name).stat().st_size,
                             "sha256": sha_file(root / name)}
                      for name in sorted(used) if (root / name).is_file()}

    def minimum_summary(items: list[dict]) -> dict | None:
        if not items:
            return None
        item = min(items, key=lambda x: x["profile_p3"]["minimum_quantization_lower_bound"])
        return {
            "file": item["file"],
            "text": item["text"],
            "font_size": item["font_size"],
            "font_weight": item["font_weight"],
            "threshold": item["threshold"],
            "minimum_p3_lower_bound": item["profile_p3"]["minimum_quantization_lower_bound"],
            "margin": item["profile_p3"]["minimum_quantization_lower_bound"] - item["threshold"],
        }

    valid_groups = [g for g in all_groups if g["capture_valid"]]
    contrast_failing_groups = [g for g in valid_groups if not g["contrast_pass"]]
    failing_pairs = [p for p in all_pairs if p["failing_themes"]]
    output = {
        "scope": "Bounded viewport-false capture batch only; no universal ICC/profile or blanket conformance claim.",
        "source_hashes": source_manifest,
        "calibration": calibration,
        "counts": {
            "app_groups": len(app_paths),
            "groups_by_family": count_by_family,
            "valid_capture_groups": len(valid_groups),
            "invalid_capture_groups": len(all_groups) - len(valid_groups),
            "leaves": sum(g["leaf_count"] for g in all_groups),
            "png_regions": image_total,
            "theme_pairs": len(all_pairs),
            "complete_theme_pairs": sum(p["complete"] for p in all_pairs),
            "pairs_with_at_least_one_contrast_failing_theme": len(failing_pairs),
            "contrast_failing_groups": len(contrast_failing_groups),
            "contrast_failing_leaves": sum(not leaf["pass"] for group in valid_groups for leaf in group["leaves"]),
            "normal_threshold_leaves": len(normal_leaves),
            "large_threshold_leaves": len(large_leaves),
        },
        "lowest_normal_text": minimum_summary(normal_leaves),
        "lowest_large_text": minimum_summary(large_leaves),
        "control_results": control_results,
        "control_expectations_match": (
            control_results["control-pass.json"]["p3_pass"] and
            not control_results["control-fail.json"]["p3_pass"] and
            not control_results["control-pass.json"]["wrong_srgb_pass"] and
            control_results["control-fail.json"]["wrong_srgb_pass"]
        ),
        "pair_failures": failing_pairs,
        "groups": all_groups,
        "diagnostic_record": diagnostic,
        "negative_counterprobes": probes,
        "input_manifest": input_manifest,
        "capture_factory_binding_limit": (
            "Each record binds the measurement-source SHA and capture API/tab parameters. "
            "The capture-factory SHA is recorded here from the supplied factory source; "
            "the per-record protocol does not embed a factory SHA."
        ),
        "top_level_errors": top_errors,
    }
    output["verification_pass"] = (
        not top_errors and
        len(valid_groups) == 72 and
        len(all_pairs) == 36 and all(p["complete"] for p in all_pairs) and
        output["control_expectations_match"] and
        probes["all_rejected"] and
        calibration["same_digest"] and
        not diagnostic_errors and
        not contrast_failing_groups and
        not failing_pairs
    )
    out_path = root / "verified-result.json"
    out_path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "result": str(out_path),
        "verification_pass": output["verification_pass"],
        "counts": output["counts"],
        "lowest_normal_text": output["lowest_normal_text"],
        "lowest_large_text": output["lowest_large_text"],
        "controls": control_results,
        "pair_failures": failing_pairs,
        "negative_counterprobes": probes,
        "top_level_errors": top_errors,
    }, indent=2))
    return 0 if output["verification_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
