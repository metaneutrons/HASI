import { createHash, createPrivateKey, generateKeyPairSync, randomUUID } from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { createInterface } from 'node:readline';
import { readFile, rm, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
import { createApi, MockIdentityProvider, PluginRegistry } from '/Users/fabian/.codex/worktrees/hasi-m2-container-proof/hasi/apps/api/src/index.ts';
import { createPluginServer, digest } from '@hasi/plugin-sdk';
import { PostgresJsonStore } from '@hasi/state';
import { Pool } from 'pg';
const REPO = '/Users/fabian/.codex/worktrees/hasi-m2-container-proof/hasi';
const HOME_DIR = '/private/tmp/hasi-p6a2-config-race.hZhVPm';
const SERVICE_TOKEN = 'synthetic-p6a2-config-race-service-token';
const ORIGIN = 'http://127.0.0.1:3000';
const PLUGIN_ID = 'p6a2.configuration.race';
const manifest = {
 manifestVersion: 2, apiVersion: '2.0.0', mcpVersion: '2026-07-28',
 id: PLUGIN_ID, name: 'P6-A2 configuration race fixture',
 description: 'Disposable local fixture.', version: '1.0.0',
 configuration: { schema: { type: 'object', properties: { label: { type: 'string', minLength: 1, maxLength: 64 } }, required: ['label'], additionalProperties: false }, fields: [{ name: 'label', label: 'Label' }] },
 tools: [{ name: 'fixture.read', title: 'Read fixture', description: 'Reads synthetic config.', effect: 'read', requiredPermissions: ['rooms:read'], inputSchema: { type: 'object', properties: {}, additionalProperties: false }, outputSchema: { type: 'object', properties: { label: { type: 'string' } }, required: ['label'], additionalProperties: false }, visibility: ['model'] }],
};
function assert(value: unknown, code: string): asserts value { if (!value) throw new Error(code); }

const RUN_ID = randomUUID();
const OWNER_LABEL = 'hasi-p6a2-config-race:' + RUN_ID;
const CONTAINER_NAME = 'hasi-p6a2-config-race-' + RUN_ID.slice(0, 12);
const NETWORK_NAME = 'hasi-p6a2-config-race-net-' + RUN_ID.slice(0, 12);
const NAMESPACE = 'p6a2-' + RUN_ID;
const SCOPE = 'p6a2-config-race-' + RUN_ID;
const IMAGE = 'postgres:18.6-alpine';
const KEY_PATH = HOME_DIR + '/ephemeral-test-key.pem';
const EVIDENCE_PATH = HOME_DIR + '/evidence.json';
const TRIGGER_SUFFIX = RUN_ID.replaceAll('-', '').slice(0, 16);
const TRIGGER_NAME = 'p6a2_delay_' + TRIGGER_SUFFIX;
const FUNCTION_NAME = 'p6a2_delay_fn_' + TRIGGER_SUFFIX;

let pluginServer: any;
let observer: any;
let containerId: string | undefined;
let networkId: string | undefined;
let containerCreated = false;
let networkCreated = false;
let postgresStep = 'not-started';
const workers: any[] = [];

function docker(args: string[]): string {
  return execFileSync('docker', args, {
    cwd: REPO, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 20000,
  }).trim();
}
function inspectId(kind: 'container' | 'network', name: string): string | undefined {
  try { return docker([kind, 'inspect', '--format', '{{.Id}}', name]); }
  catch { return undefined; }
}
function inspectLabel(kind: 'container' | 'network', id: string): string | undefined {
  try {
    const format = kind === 'container'
      ? '{{ index .Config.Labels "org.hasi.codex.task" }}'
      : '{{ index .Labels "org.hasi.codex.task" }}';
    return docker([kind, 'inspect', '--format', format, id]);
  } catch { return undefined; }
}
function hash(bytes: Uint8Array): string { return createHash('sha256').update(bytes).digest('hex'); }

async function startPostgres(): Promise<{ port: number; version: string; imageId: string }> {
  postgresStep = 'inspect_image';
  const imageId = docker(['image', 'inspect', '--format', '{{.Id}}', IMAGE]);
  postgresStep = 'create_network';
  networkId = docker(['network', 'create', '--label', 'org.hasi.codex.task=' + OWNER_LABEL, NETWORK_NAME]);
  networkCreated = true;
  postgresStep = 'verify_network_label';
  assert(inspectLabel('network', networkId) === OWNER_LABEL, 'owned_network_label_missing');
  postgresStep = 'run_container';
  docker([
    'run', '--detach', '--name', CONTAINER_NAME,
    '--label', 'org.hasi.codex.task=' + OWNER_LABEL,
    '--network', NETWORK_NAME,
    '--publish', '127.0.0.1::5432',
    '--tmpfs', '/tmp/pgdata:rw,noexec,nosuid,size=128m',
    '--env', 'PGDATA=/tmp/pgdata',
    '--env', 'POSTGRES_HOST_AUTH_METHOD=trust',
    '--env', 'POSTGRES_DB=hasi_race',
    '--env', 'POSTGRES_USER=hasi_test',
    IMAGE,
  ]);
  postgresStep = 'inspect_container';
  containerId = inspectId('container', CONTAINER_NAME);
  assert(containerId, 'owned_postgres_container_missing');
  containerCreated = true;
  postgresStep = 'verify_container_label';
  assert(inspectLabel('container', containerId) === OWNER_LABEL, 'owned_container_label_missing');
  postgresStep = 'wait_for_postgres';
  let ready = false;
  for (let attempt = 0; attempt < 80; attempt += 1) {
    try {
      docker(['exec', containerId, 'pg_isready', '-U', 'hasi_test', '-d', 'hasi_race']);
      ready = true;
      break;
    } catch { await delay(250); }
  }
  assert(ready, 'owned_postgres_not_ready');
  postgresStep = 'read_loopback_port';
  const portText = docker(['port', containerId, '5432/tcp']);
  const match = /^127\.0\.0\.1:(\d+)$/u.exec(portText);
  assert(match, 'owned_postgres_loopback_port_invalid');
  const port = Number(match[1]);
  assert(Number.isSafeInteger(port) && port > 0 && port <= 65535, 'owned_postgres_port_invalid');
  postgresStep = 'connect_observer';
  observer = new Pool({
    connectionString: 'postgres://hasi_test@127.0.0.1:' + port + '/hasi_race',
    max: 1, application_name: 'p6a2-observer', connectionTimeoutMillis: 5000, idleTimeoutMillis: 1000,
  });
  postgresStep = 'read_postgres_version';
  let result: any;
  for (let attempt = 0; attempt < 50; attempt += 1) {
    try { result = await observer.query('SELECT version() AS version'); break; }
    catch { await delay(100); }
  }
  assert(result, 'postgres_host_connection_not_ready');
  postgresStep = 'complete';
  return { port, version: String(result.rows[0]?.version ?? 'unknown'), imageId };
}

async function runApiChild(): Promise<void> {
  const id = process.env.P6A2_WORKER_ID;
  const dbUrl = process.env.P6A2_DATABASE_URL;
  const namespace = process.env.P6A2_NAMESPACE;
  const scope = process.env.P6A2_SCOPE;
  const pluginId = process.env.P6A2_PLUGIN_ID;
  const endpoint = process.env.P6A2_PLUGIN_ENDPOINT;
  const manifestDigest = process.env.P6A2_MANIFEST_DIGEST;
  const serviceToken = process.env.P6A2_SERVICE_TOKEN;
  const keyPath = process.env.P6A2_SIGNING_KEY_PATH;
  assert(id && dbUrl && namespace && scope && pluginId && endpoint && manifestDigest && serviceToken && keyPath, 'api_child_environment_invalid');
  const store = new PostgresJsonStore(namespace, {
    poolConfig: {
      connectionString: dbUrl, max: 4, application_name: 'p6a2-api-' + id,
      connectionTimeoutMillis: 5000, idleTimeoutMillis: 2000,
    },
  });
  const registry = new PluginRegistry(createPrivateKey(await readFile(keyPath)), { store, scope });
  let api: any;
  let stopping = false;
  const shutdown = async () => {
    if (stopping) return;
    stopping = true;
    try { if (api) await api.close(); } finally { await store.close(); }
  };
  process.once('SIGTERM', () => {
    void shutdown().then(() => { process.exitCode = 0; }).catch(() => { process.exitCode = 1; });
  });
  try {
    await store.initialize();
    await registry.install({
      instanceId: pluginId, endpoint, serviceToken, expectedManifestDigest: manifestDigest, allowLoopback: true,
    });
    api = await createApi({
      mode: 'test', registry, identity: new MockIdentityProvider('test'), store,
      origin: ORIGIN, allowedHosts: ['127.0.0.1'],
    });
    const address = await api.listen({ host: '127.0.0.1', port: 0 });
    const match = /:(\d+)$/u.exec(address);
    assert(match, 'api_child_listen_address_invalid');
    process.stdout.write(JSON.stringify({ event: 'ready', workerId: id, pid: process.pid, port: Number(match[1]) }) + '\n');
    await new Promise(() => {});
  } catch (error) {
    await shutdown();
    process.stderr.write(error instanceof Error ? error.message.slice(0, 256) : 'api_child_start_failed');
    process.stderr.write('\n');
    process.exitCode = 1;
  }
}

async function startApiWorker(id: string, port: number, keyPath: string, endpoint: string, manifestDigest: string): Promise<any> {
  const childEnv = {
    PATH: process.env.PATH ?? '/usr/bin:/bin',
    HOME: process.env.HOME ?? '/tmp',
    TMPDIR: process.env.TMPDIR ?? '/tmp',
    P6A2_WORKER_ID: id,
    P6A2_DATABASE_URL: 'postgres://hasi_test@127.0.0.1:' + port + '/hasi_race',
    P6A2_NAMESPACE: NAMESPACE,
    P6A2_SCOPE: SCOPE,
    P6A2_PLUGIN_ID: PLUGIN_ID,
    P6A2_PLUGIN_ENDPOINT: endpoint,
    P6A2_MANIFEST_DIGEST: manifestDigest,
    P6A2_SERVICE_TOKEN: SERVICE_TOKEN,
    P6A2_SIGNING_KEY_PATH: keyPath,
  };
  const child = spawn(process.execPath, [...process.execArgv, fileURLToPath(import.meta.url), '--api-child'], {
    cwd: REPO, env: childEnv, stdio: ['ignore', 'pipe', 'pipe'],
  });
  assert(typeof child.pid === 'number', 'api_child_pid_missing');
  const worker: any = { id, child, pid: child.pid, port: 0, stderr: '', exited: new Promise(resolve => child.once('exit', resolve)) };
  workers.push(worker);
  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk: string) => { worker.stderr = (worker.stderr + chunk).slice(-4096); });
  const readyPort = await Promise.race([
    new Promise<number>((resolve, reject) => {
      const lines = createInterface({ input: child.stdout });
      lines.on('line', line => {
        try {
          const message = JSON.parse(line);
          if (message.event === 'ready' && message.workerId === id && Number.isInteger(message.port)) {
            lines.close();
            resolve(message.port);
          }
        } catch { /* Child stdout is protocol-only. */ }
      });
      child.once('error', () => { lines.close(); reject(new Error('api_child_spawn_failed')); });
      child.once('exit', () => { lines.close(); reject(new Error('api_child_exited_before_ready')); });
    }),
    delay(30000, undefined, { ref: false }).then(() => { throw new Error('api_child_ready_timeout'); }),
  ]);
  worker.port = readyPort;
  return worker;
}

async function request(worker: any, method: string, path: string, body?: unknown, cookie?: string): Promise<any> {
  const headers: Record<string, string> = { origin: ORIGIN };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (cookie) headers.cookie = cookie;
  const response = await fetch('http://127.0.0.1:' + worker.port + path, {
    method, headers, ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  const text = await response.text();
  let parsed: any = null;
  try { parsed = text ? JSON.parse(text) : null; } catch { parsed = null; }
  return { status: response.status, body: parsed, headers: response.headers };
}
function asRecord(value: any): Record<string, any> {
  assert(typeof value === 'object' && value !== null && !Array.isArray(value), 'api_json_object_expected');
  return value;
}
async function loginCookie(worker: any, personaId: 'admin' | 'student'): Promise<string> {
  const response = await request(worker, 'POST', '/api/dev/login', { personaId });
  assert(response.status === 200, 'test_identity_login_failed');
  const setCookie = response.headers.get('set-cookie');
  assert(setCookie, 'test_identity_cookie_missing');
  return setCookie.split(';', 1)[0];
}
async function readConfiguration(worker: any, cookie: string): Promise<Record<string, any>> {
  const response = await request(worker, 'GET', '/api/admin/plugins/' + PLUGIN_ID + '/configuration', undefined, cookie);
  assert(response.status === 200, 'configuration_read_failed');
  return asRecord(response.body);
}
async function observeOverlap(databaseObserver: any): Promise<{ apiNames: string[]; lockWaitObserved: boolean }> {
  const deadline = Date.now() + 5000;
  let last: any = { api_names: [], lock_wait_observed: false };
  const sql = "SELECT array_agg(DISTINCT application_name ORDER BY application_name) "
    + "FILTER (WHERE state = 'active' AND position('UPDATE hasi_state_v1' IN query) > 0) AS api_names, "
    + "bool_or(state = 'active' AND wait_event_type = 'Lock' "
    + "AND position('UPDATE hasi_state_v1' IN query) > 0) AS lock_wait_observed "
    + "FROM pg_stat_activity WHERE application_name IN ('p6a2-api-a', 'p6a2-api-b')";
  while (Date.now() < deadline) {
    const result = await databaseObserver.query(sql);
    last = result.rows[0] ?? last;
    const names = last.api_names ?? [];
    if (names.includes('p6a2-api-a') && names.includes('p6a2-api-b') && last.lock_wait_observed === true) {
      return { apiNames: names, lockWaitObserved: true };
    }
    await delay(20);
  }
  return { apiNames: last.api_names ?? [], lockWaitObserved: last.lock_wait_observed === true };
}
async function racePhase(databaseObserver: any, workerA: any, workerB: any, adminA: string, adminB: string, path: string, revision: number, valueA?: string, valueB?: string): Promise<any> {
  const bodyA = valueA === undefined ? { revision } : { revision, values: { label: valueA }, disabledTools: [] };
  const bodyB = valueB === undefined ? { revision } : { revision, values: { label: valueB }, disabledTools: [] };
  const pending = Promise.all([
    request(workerA, 'POST', path, bodyA, adminA),
    request(workerB, 'POST', path, bodyB, adminB),
  ]);
  const overlap = await observeOverlap(databaseObserver);
  const results = await pending;
  const statuses = results.map(result => result.status).sort((a: number, b: number) => a - b);
  assert(statuses[0] === 200 && statuses[1] === 409, 'same_revision_cas_outcome_invalid');
  const conflict = results.find(result => result.status === 409);
  assert(asRecord(conflict?.body).error === 'Die Konfiguration wurde parallel geändert. Bitte neu laden.', 'expected_revision_conflict_not_observed');
  assert(overlap.apiNames.includes('p6a2-api-a') && overlap.apiNames.includes('p6a2-api-b') && overlap.lockWaitObserved, 'postgres_concurrency_not_observed');
  return { statuses, overlap, expectedRevisionConflict: true };
}
async function stopWorkers(): Promise<boolean> {
  let stopped = true;
  await Promise.all(workers.map(async worker => {
    if (worker.child.exitCode !== null || worker.child.signalCode !== null) return;
    worker.child.kill('SIGTERM');
    const exited = await Promise.race([worker.exited.then(() => true), delay(5000).then(() => false)]);
    if (!exited) {
      worker.child.kill('SIGKILL');
      const forced = await Promise.race([worker.exited.then(() => true), delay(2000).then(() => false)]);
      if (!forced) stopped = false;
    }
  }));
  return stopped;
}
async function cleanupOwnedDocker(): Promise<{ containerRemoved: boolean; networkRemoved: boolean }> {
  let containerRemoved = true;
  const ownedContainer = containerId ?? inspectId('container', CONTAINER_NAME);
  if (ownedContainer) {
    if (inspectLabel('container', ownedContainer) !== OWNER_LABEL) containerRemoved = false;
    else { try { docker(['rm', '--force', '--volumes', ownedContainer]); } catch { containerRemoved = false; } }
  }
  if (containerCreated && inspectId('container', CONTAINER_NAME)) containerRemoved = false;
  let networkRemoved = true;
  const ownedNetwork = networkId ?? inspectId('network', NETWORK_NAME);
  if (ownedNetwork) {
    if (inspectLabel('network', ownedNetwork) !== OWNER_LABEL) networkRemoved = false;
    else { try { docker(['network', 'rm', ownedNetwork]); } catch { networkRemoved = false; } }
  }
  if (networkCreated && inspectId('network', NETWORK_NAME)) networkRemoved = false;
  return { containerRemoved, networkRemoved };
}

async function main(): Promise<void> {
  let currentPhase = 'source_fingerprint';
  let failurePhase: string | null = null;
  let failureType: string | null = null;
  let failureCode: string | null = null;
  let gitHead = 'unknown';
  let sourceHashes: Record<string, string> = {};
  let pgVersion = 'not-started';
  let pgImageId = 'unknown';
  let apiProcesses: { workerId: string; pid: number }[] = [];
  let unauthenticatedStatus = 0;
  let studentStatus = 0;
  let forbiddenWriteUnchanged = false;
  let draftRace: any = null;
  let activationRace: any = null;
  let finalState: any = null;
  let replicasConverged = false;
  let qualified = false;
  let apiProcessesTerminated = false;
  let pluginServerStopped = false;
  let observerClosed = false;
  let keyRemoved = false;
  let dockerCleanup = { containerRemoved: false, networkRemoved: false };

  try {
    for (const file of [
      'apps/api/src/plugin-settings.ts',
      'apps/api/src/index.ts',
      'apps/api/src/registry.ts',
      'apps/api/src/identity.ts',
      'packages/state/src/postgres.ts',
      'packages/state/src/update.ts',
      'packages/plugin-sdk/src/canonical-json.ts',
      'packages/plugin-sdk/src/server.ts',
    ]) {
      sourceHashes[file] = hash(await readFile(REPO + '/' + file));
    }
    gitHead = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: REPO, encoding: 'utf8' }).trim();

    currentPhase = 'postgres_start';
    const pg = await startPostgres();
    pgVersion = pg.version;
    pgImageId = pg.imageId;

    currentPhase = 'synthetic_plugin_start';
    const pair = generateKeyPairSync('ed25519');
    await writeFile(KEY_PATH, pair.privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
    const manifestDigest = digest(manifest);
    pluginServer = createPluginServer({
      manifest,
      publicKey: pair.publicKey,
      serviceToken: SERVICE_TOKEN,
      handlers: {
        'fixture.read': (_args: unknown, _actor: unknown, context: any) => Promise.resolve({ label: String(context?.configuration?.label ?? '') }),
      },
    });
    await pluginServer.listen({ host: '127.0.0.1', port: 0 });
    const pluginAddress = pluginServer.server.address();
    assert(pluginAddress && typeof pluginAddress !== 'string', 'synthetic_plugin_listen_failed');
    const pluginEndpoint = 'http://127.0.0.1:' + pluginAddress.port + '/mcp';

    currentPhase = 'two_api_process_start';
    const workerA = await startApiWorker('a', pg.port, KEY_PATH, pluginEndpoint, manifestDigest);
    const workerB = await startApiWorker('b', pg.port, KEY_PATH, pluginEndpoint, manifestDigest);
    assert(workerA.pid !== workerB.pid, 'api_processes_not_distinct');
    apiProcesses = workers.map(worker => ({ workerId: worker.id, pid: worker.pid }));

    currentPhase = 'admin_and_denial_checks';
    const unauthenticated = await request(workerA, 'GET', '/api/admin/plugins/' + PLUGIN_ID + '/configuration');
    unauthenticatedStatus = unauthenticated.status;
    assert(unauthenticatedStatus === 401, 'unauthenticated_configuration_read_not_denied');
    const adminA = await loginCookie(workerA, 'admin');
    const adminB = await loginCookie(workerB, 'admin');
    const studentB = await loginCookie(workerB, 'student');
    const configPath = '/api/admin/plugins/' + PLUGIN_ID + '/configuration';
    const initialA = await readConfiguration(workerA, adminA);
    const initialB = await readConfiguration(workerB, adminB);
    assert(initialA.revision === 0 && initialB.revision === 0, 'initial_configuration_revision_not_zero');

    currentPhase = 'seed_shared_revision';
    const seeded = await request(workerA, 'POST', configPath + '/draft', {
      revision: 0, values: { label: 'seed' }, disabledTools: [],
    }, adminA);
    assert(seeded.status === 200, 'initial_configuration_draft_failed');
    const seedA = await readConfiguration(workerA, adminA);
    const seedB = await readConfiguration(workerB, adminB);
    assert(seedA.revision === 1 && seedB.revision === 1, 'seeded_revision_not_shared');

    currentPhase = 'admin_denial';
    const denied = await request(workerB, 'POST', configPath + '/draft', {
      revision: 1, values: { label: 'student-attempt' }, disabledTools: [],
    }, studentB);
    studentStatus = denied.status;
    assert(studentStatus === 403, 'non_admin_configuration_write_not_denied');
    const afterDenied = await readConfiguration(workerA, adminA);
    forbiddenWriteUnchanged = afterDenied.revision === 1 && asRecord(afterDenied.draft).label === 'seed';
    assert(forbiddenWriteUnchanged, 'forbidden_write_changed_configuration');

    currentPhase = 'database_overlap_barrier';
    const settingsKey = 'plugin-settings:v1:' + digest({ scope: SCOPE, instanceId: PLUGIN_ID });
    const triggerSql = 'CREATE FUNCTION ' + FUNCTION_NAME + '() RETURNS trigger LANGUAGE plpgsql AS $body$ '
      + 'BEGIN IF NEW.namespace = ' + "'" + NAMESPACE + "'" + ' AND NEW.key = ' + "'" + settingsKey + "' "
      + 'THEN PERFORM pg_sleep(1.5); END IF; RETURN NEW; END; $body$; '
      + 'CREATE TRIGGER ' + TRIGGER_NAME + ' BEFORE UPDATE ON hasi_state_v1 FOR EACH ROW EXECUTE FUNCTION ' + FUNCTION_NAME + '()';
    await observer.query(triggerSql);

    currentPhase = 'simultaneous_draft_mutation';
    draftRace = await racePhase(observer, workerA, workerB, adminA, adminB, configPath + '/draft', 1, 'candidate-a', 'candidate-b');
    const draftStateA = await readConfiguration(workerA, adminA);
    const draftStateB = await readConfiguration(workerB, adminB);
    const winningDraft = asRecord(draftStateA.draft).label;
    assert(draftStateA.revision === 2 && draftStateB.revision === 2, 'draft_race_revisions_not_converged');
    assert(draftStateA.activeRevision === 0 && draftStateB.activeRevision === 0, 'draft_race_activated_configuration');
    assert((winningDraft === 'candidate-a' || winningDraft === 'candidate-b')
      && asRecord(draftStateB.draft).label === winningDraft, 'draft_race_winner_not_converged');

    currentPhase = 'simultaneous_activation_mutation';
    activationRace = await racePhase(observer, workerA, workerB, adminA, adminB, configPath + '/activate', 2);
    const finalA = await readConfiguration(workerA, adminA);
    const finalB = await readConfiguration(workerB, adminB);
    const activeLabel = asRecord(finalA.configuration).label;
    replicasConverged = finalA.revision === 3 && finalB.revision === 3
      && finalA.activeRevision === 1 && finalB.activeRevision === 1
      && activeLabel === winningDraft
      && asRecord(finalA.draft).label === winningDraft
      && asRecord(finalB.configuration).label === activeLabel
      && asRecord(finalB.draft).label === winningDraft;
    assert(replicasConverged, 'activation_race_state_not_converged');
    finalState = {
      revision: finalA.revision,
      activeRevision: finalA.activeRevision,
      draftLabel: winningDraft,
      activeLabel,
    };
    qualified = true;
  } catch (error) {
    failurePhase = currentPhase;
    failureType = error instanceof Error ? error.name : 'UnknownError';
    failureCode = currentPhase === 'postgres_start' ? postgresStep : null;
  } finally {
    apiProcessesTerminated = await stopWorkers();
    if (pluginServer) {
      try { await pluginServer.close(); pluginServerStopped = true; } catch { pluginServerStopped = false; }
      pluginServer = undefined;
    } else {
      pluginServerStopped = true;
    }
    if (observer) {
      try { await observer.end(); observerClosed = true; } catch { observerClosed = false; }
      observer = undefined;
    } else {
      observerClosed = true;
    }
    try { await rm(KEY_PATH, { force: true }); keyRemoved = true; } catch { keyRemoved = false; }
    dockerCleanup = await cleanupOwnedDocker();
  }

  const cleanupVerified = apiProcessesTerminated && pluginServerStopped && observerClosed
    && keyRemoved && dockerCleanup.containerRemoved && dockerCleanup.networkRemoved;
  const passed = qualified && cleanupVerified;
  const scriptBytes = await readFile(fileURLToPath(import.meta.url));
  const report = {
    objective: 'P6-A2 two-process plugin configuration expected-revision race',
    runId: RUN_ID,
    ownedDockerNames: { container: CONTAINER_NAME, network: NETWORK_NAME },
    gitHead,
    sourceSha256: sourceHashes,
    helperSha256: hash(scriptBytes),
    topology: {
      apiProcessCount: apiProcesses.length,
      apiProcesses,
      distinctOperatingSystemProcesses: apiProcesses.length === 2 && apiProcesses[0]?.pid !== apiProcesses[1]?.pid,
      postgresImage: IMAGE,
      postgresImageId: pgImageId,
      postgresVersion: pgVersion,
      databaseIngress: 'ephemeral host port bound to 127.0.0.1; private labeled Docker network',
      fixture: 'loopback-only synthetic MCP plugin',
      realProviderCalls: 0,
      businessToolCalls: 0,
    },
    assertions: {
      unauthenticatedAdminReadStatus: unauthenticatedStatus,
      nonAdminWriteStatus: studentStatus,
      rejectedNonAdminWriteLeftStateUnchanged: forbiddenWriteUnchanged,
      draftRace: draftRace ? {
        sameExpectedRevision: 1,
        httpStatuses: draftRace.statuses,
        oneConflict: draftRace.statuses.filter((status: number) => status === 409).length === 1,
        expectedRevisionConflict: draftRace.expectedRevisionConflict,
        concurrentApiApplicationNames: draftRace.overlap.apiNames,
        postgresLockWaitObserved: draftRace.overlap.lockWaitObserved,
      } : null,
      activationRace: activationRace ? {
        sameExpectedRevision: 2,
        httpStatuses: activationRace.statuses,
        oneConflict: activationRace.statuses.filter((status: number) => status === 409).length === 1,
        expectedRevisionConflict: activationRace.expectedRevisionConflict,
        concurrentApiApplicationNames: activationRace.overlap.apiNames,
        postgresLockWaitObserved: activationRace.overlap.lockWaitObserved,
      } : null,
      bothApiReadsConverged: replicasConverged,
      finalState,
    },
    cleanup: {
      apiProcessesTerminated,
      pluginServerStopped,
      observerClosed,
      testSigningKeyRemoved: keyRemoved,
      ownedPostgresContainerRemoved: dockerCleanup.containerRemoved,
      ownedDockerNetworkRemoved: dockerCleanup.networkRemoved,
      verified: cleanupVerified,
    },
    qualified: passed,
    failurePhase,
    failureType,
    failureCode,
    exitStatus: passed ? 0 : 1,
    evidenceAllowlist: 'No database URL, password, cookie, session token, signing key, signature, request body, or header value is recorded.',
  };
  await writeFile(EVIDENCE_PATH, JSON.stringify(report, null, 2) + '\n', { mode: 0o600 });
  process.stdout.write(JSON.stringify(report) + '\n');
  if (!passed) process.exitCode = 1;
}

if (process.argv.includes('--api-child')) {
  await runApiChild();
} else {
  await main();
}
