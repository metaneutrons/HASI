P6-A2 configuration race qualification

Run from the repository root with:
node --import tsx /private/tmp/hasi-p6a2-config-race.hZhVPm/qualify-p6a2-config-race.mts

The helper creates a uniquely labeled private Docker network and PostgreSQL 18.6 container, bound only to an ephemeral 127.0.0.1 port. It launches two independent API OS processes, exercises the HTTP admin routes with test personas, forces and observes database row-lock overlap, and removes only resources carrying its unique ownership label. It writes allowlisted results to evidence.json. It uses a local synthetic plugin and makes no model/provider or business-tool calls.
