#!/usr/bin/env python3
"""Independent verifier for the bounded HASI viewport-false contrast batch."""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import math
import re
import tempfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
MEASURE_SOURCE = ROOT / "measure-source.js"
CAPTURE_FACTORY = ROOT / "capture-factory.js"
HELPER_PATH = ROOT / "png-color-helper.py"

spec = importlib.util.spec_from_file_location("hasi_color", HELPER_PATH)
color = importlib.util.module_from_spec(spec)
spec.loader.exec_module(color)


class Reject(Exception):
    pass


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def require(ok: bool, reason: str, errors: list[str]) -> None:
    if not ok:
        errors.append(reason)


def expected_threshold(leaf: dict) -> float:
    size = float(str(leaf["fontSize"]).removesuffix("px"))
    weight = float(leaf["fontWeight"])
    return 3.0 if size >= 24 or (size >= 18.667 and weight >= 700) else 4.5


def geometry(record: dict) -> dict:
    leaves = record.get("leaves", [])
    return {
        "target": record.get("target"),
        "scroll": record.get("scroll"),
        "ancestors": [leaf.get("ancestors") for leaf in leaves],
        "regions": [[{
            "raw": region.get("raw"),
            "visible": region.get("visible"),
            "hits": region.get("hits"),
            "clip": region.get("clip"),
        } for region in leaf.get("regions", [])] for leaf in leaves],
    }


def lower_ratio(foreground_y: float, low: float, high: float) -> float:
    # Include the interior minimum when the quantization interval crosses the
    # foreground luminance; endpoint-only minima would not be a true lower bound.
    if low <= foreground_y <= high:
        return 1.0
    return min(color.ratio(foreground_y, low), color.ratio(foreground_y, high))


def profile_scores(foreground_rgb: tuple[int, int, int], pixels: list[tuple[int, int, int]], weights: tuple[float, float, float]) -> dict:
    foreground_y = color.Y(foreground_rgb, color.W_SRGB)
    point = []
    lower = []
    for rgb in pixels:
        background_y = color.Y(rgb, weights)
        point.append(color.ratio(foreground_y, background_y))
        low, high = color.y_interval(rgb, weights)
        lower.append(lower_ratio(foreground_y, low, high))
    return {
        "minimum_point_ratio": min(point),
        "minimum_quantization_lower_bound": min(lower),
        "pixel_count": len(pixels),
    }


def verify_record(record: dict, filename: str, root: Path, measure_sha: str,
                  png_overrides: dict[str, Path] | None = None) -> tuple[list[str], list[dict], int]:
    errors: list[str] = []
    png_overrides = png_overrides or {}
    req = lambda ok, why: require(bool(ok), why, errors)

    protocol = record.get("protocol", {})
    req(protocol.get("tabId") == "25", f"{filename}: unexpected tab id")
    req(protocol.get("method") == "Page.captureScreenshot", f"{filename}: unexpected capture API")
    req(protocol.get("captureBeyondViewport") is False, f"{filename}: captureBeyondViewport was not false")
    req(protocol.get("sourceSha256") == measure_sha, f"{filename}: measurement source hash mismatch")
    req(record.get("viewport") in [{"dpr": 1, "height": 844, "width": w} for w in (320, 375, 390)],
        f"{filename}: unexpected viewport")
    req(record.get("url", "").startswith("https://hasi.metaneutrons.cc/"),
        f"{filename}: unexpected page origin")

    leaves = record.get("leaves")
    if not isinstance(leaves, list) or not leaves:
        return errors + [f"{filename}: missing text leaves"], [], 0
    req(record.get("target") is not None and record.get("scroll") is not None,
        f"{filename}: missing target or scroll")
    req(len(record.get("maskedFills", [])) == len(leaves),
        f"{filename}: mask fill count differs from text leaves")
    req(all(fill == "rgba(0, 0, 0, 0)" for fill in record.get("maskedFills", [])),
        f"{filename}: one or more text leaves remained visible under mask")

    initial = record.get("initial", {})
    restored_original = record.get("originalRestoration", {})
    req(restored_original.get("scroll") == initial.get("scroll"),
        f"{filename}: original root scroll was not restored")
    req(restored_original.get("parents") == initial.get("parents"),
        f"{filename}: original ancestor scroll/style state was not restored")
    req(restored_original.get("maskAbsent") is True,
        f"{filename}: temporary mask remained after restoration")
    restored = record.get("restored", {})
    req(restored.get("target") == record.get("target"),
        f"{filename}: target geometry changed after mask removal")
    req(restored.get("scroll") == record.get("scroll"),
        f"{filename}: observed root scroll changed after mask removal")
    cleaned = copy.deepcopy(leaves)
    for leaf in cleaned:
        for region in leaf.get("regions", []):
            region.pop("file", None)
            region.pop("sha256", None)
    req(cleaned == restored.get("leaves"),
        f"{filename}: leaf styles/geometry changed after mask removal")

    expected_files = []
    leaf_metrics: list[dict] = []
    total_images = 0
    theme_match = re.match(r"^app-mobile-(?:320|375|390)-(?:chat|admin)-(light|dark)-", filename)
    if theme_match:
        req(initial.get("theme") == theme_match.group(1),
            f"{filename}: recorded theme differs from filename")

    for li, leaf in enumerate(leaves):
        try:
            fg = color.parse_rgb(leaf.get("fill"))
        except Exception as exc:
            errors.append(f"{filename}: leaf {li}: unsupported foreground: {exc}")
            continue
        req(leaf.get("fill") == leaf.get("color"),
            f"{filename}: leaf {li}: text fill differs from CSS color")
        req(leaf.get("textShadow") == "none",
            f"{filename}: leaf {li}: text shadow is not none")
        try:
            threshold = expected_threshold(leaf)
            req(float(leaf.get("threshold")) == threshold,
                f"{filename}: leaf {li}: stored threshold does not match computed font threshold")
        except Exception as exc:
            errors.append(f"{filename}: leaf {li}: invalid font threshold data: {exc}")
            threshold = float(leaf.get("threshold", 4.5))

        for ai, ancestor in enumerate(leaf.get("ancestors", [])):
            for key, expected in (("opacity", "1"), ("filter", "none"),
                                  ("blend", "normal"), ("clipPath", "none"),
                                  ("clip", "auto"), ("maskImage", "none")):
                req(ancestor.get(key) == expected,
                    f"{filename}: leaf {li}: ancestor {ai} {key}={ancestor.get(key)!r}")
            req("paint" not in str(ancestor.get("contain", "")),
                f"{filename}: leaf {li}: ancestor {ai} uses paint containment")

        all_pixels: list[tuple[int, int, int]] = []
        for ri, region in enumerate(leaf.get("regions", [])):
            total_images += 1
            file = region.get("file", "")
            expected_files.append(file)
            req(isinstance(file, str) and Path(file).name == file,
                f"{filename}: leaf {li} region {ri}: nonlocal image path")
            if not isinstance(file, str) or Path(file).name != file:
                continue

            visible = region.get("visible", {})
            clip = region.get("clip", {})
            scroll = record.get("scroll", {})
            try:
                x0 = math.floor(visible["left"])
                y0 = math.floor(visible["top"])
                x1 = math.ceil(visible["right"])
                y1 = math.ceil(visible["bottom"])
                expected_clip = {
                    "x": x0 + scroll["x"],
                    "y": y0 + scroll["y"],
                    "width": x1 - x0,
                    "height": y1 - y0,
                    "scale": 1,
                }
                req(clip == expected_clip,
                    f"{filename}: leaf {li} region {ri}: clip does not enclose the visible text rect")
            except Exception as exc:
                errors.append(f"{filename}: leaf {li} region {ri}: malformed visible/clip geometry: {exc}")

            hits = region.get("hits", [])
            req(len(hits) == 9 and all(hit.get("withinTextParent") is True for hit in hits),
                f"{filename}: leaf {li} region {ri}: incomplete hit-test grid")
            try:
                for hit in hits:
                    req(visible["left"] <= hit["x"] <= visible["right"] and
                        visible["top"] <= hit["y"] <= visible["bottom"],
                        f"{filename}: leaf {li} region {ri}: hit point outside visible rect")
            except Exception as exc:
                errors.append(f"{filename}: leaf {li} region {ri}: malformed hit point: {exc}")

            check = None
            checks = record.get("imageChecks", [])
            if ri == 0 and li == 0:
                pass
            for item in checks:
                if item.get("file") == file:
                    check = item
                    break
            req(check is not None, f"{filename}: image check missing for {file}")
            if check is not None:
                req(check.get("args") == {
                    "format": "png",
                    "captureBeyondViewport": False,
                    "clip": clip,
                }, f"{filename}: capture arguments differ from recorded clip for {file}")
                req(check.get("after") == geometry(record),
                    f"{filename}: target/scroll/ancestor/clip geometry changed during capture of {file}")

            path = png_overrides.get(file, root / file)
            try:
                data = path.read_bytes()
            except Exception as exc:
                errors.append(f"{filename}: cannot read {file}: {exc}")
                continue
            req(sha_bytes(data) == region.get("sha256"),
                f"{filename}: PNG hash mismatch for {file}")
            try:
                image = color.read_png(path)
            except Exception as exc:
                errors.append(f"{filename}: invalid PNG {file}: {exc}")
                continue
            req((image["width"], image["height"]) == (clip.get("width"), clip.get("height")),
                f"{filename}: PNG dimensions do not match clip for {file}")
            all_pixels.extend(tuple(rgb) for row in image["pixels"] for rgb in row)

        leaf_metrics.append({
            "leaf_index": li,
            "text": leaf.get("text", ""),
            "font_size": leaf.get("fontSize"),
            "font_weight": leaf.get("fontWeight"),
            "threshold": threshold,
            "foreground_css_srgb": fg,
            "profile_p3": profile_scores(fg, all_pixels, color.W_P3) if all_pixels else None,
            "profile_srgb": profile_scores(fg, all_pixels, color.W_SRGB) if all_pixels else None,
            "pass": bool(all_pixels) and profile_scores(fg, all_pixels, color.W_P3)["minimum_quantization_lower_bound"] >= threshold,
            "background_palette": [{"rgb": rgb, "count": count} for rgb, count in sorted(Counter(all_pixels).items())],
        })

    check_files = [item.get("file") for item in record.get("imageChecks", [])]
    req(check_files == expected_files,
        f"{filename}: image-check order/count differs from measured regions")
    req(len(record.get("imageChecks", [])) == total_images,
        f"{filename}: image-check count differs from measured regions")

    return errors, leaf_metrics, total_images


def calibrate(root: Path) -> dict:
    errors: list[str] = []
    meta = json.loads((root / "calibration.json").read_text())
    proof = json.loads((root / "calibration-proof.json").read_text())
    expected_hex = meta["setup"]["colors"]
    require(len(expected_hex) == 13, "calibration must declare 13 CSS colors", errors)
    require(len(meta.get("captures", [])) == 2, "calibration must contain two captures", errors)
    require(len(proof) == 2, "calibration proof must contain two capture entries", errors)
    proof_by_file = {x["file"]: x for x in proof}
    capture_results = []
    digest_list = []
    for entry in meta.get("captures", []):
        filename = entry["file"]
        before = entry["before"]
        after = entry["after"]
        rect = before["rect"]
        scroll = before["scroll"]
        require(after.get("rect") == rect and after.get("scroll") == scroll,
                f"{filename}: calibration state changed during capture", errors)
        args = entry["args"]
        expected_args = {
            "format": "png",
            "captureBeyondViewport": False,
            "clip": {
                "x": rect["left"] + scroll["x"],
                "y": rect["top"] + scroll["y"],
                "width": rect["width"],
                "height": rect["height"],
                "scale": 1,
            },
        }
        require(args == expected_args, f"{filename}: calibration clip args mismatch", errors)
        path = root / filename
        data = path.read_bytes()
        digest = sha_bytes(data)
        digest_list.append(digest)
        p = proof_by_file.get(filename, {})
        require(p.get("sha256") == digest, f"{filename}: calibration proof hash mismatch", errors)
        require(p.get("stable") is True and p.get("patches") == 13 and p.get("quadrants") == 4,
                f"{filename}: calibration proof summary mismatch", errors)
        image = color.read_png(path)
        require((image["width"], image["height"], image["depth"], image["colorType"]) == (260, 100, 8, 2),
                f"{filename}: calibration must be 260x100 8-bit RGB", errors)
        patch_details = []
        pixels_checked = 0
        for i, hex_color in enumerate(expected_hex):
            rgb = tuple(int(hex_color[j:j + 2], 16) for j in (1, 3, 5))
            expected = color.predicted_p3(rgb)[0]
            patch = [image["pixels"][y][x]
                     for y in range(20) for x in range(i * 20, (i + 1) * 20)]
            require(all(value == expected for value in patch),
                    f"{filename}: top patch {i} differs from predicted P3 {expected}", errors)
            pixels_checked += len(patch)
            patch_details.append({"css_srgb": hex_color, "observed_p3": expected, "pixels": len(patch)})
        quadrant_details = []
        for i, hex_color in enumerate(expected_hex[:4]):
            rgb = tuple(int(hex_color[j:j + 2], 16) for j in (1, 3, 5))
            expected = color.predicted_p3(rgb)[0]
            x0, x1 = (i % 2) * 130, (i % 2 + 1) * 130
            y0, y1 = 20 + (i // 2) * 40, 20 + (i // 2 + 1) * 40
            quadrant = [image["pixels"][y][x] for y in range(y0, y1) for x in range(x0, x1)]
            require(all(value == expected for value in quadrant),
                    f"{filename}: quadrant {i} differs from predicted P3 {expected}", errors)
            pixels_checked += len(quadrant)
            quadrant_details.append({"css_srgb": hex_color, "observed_p3": expected, "pixels": len(quadrant)})
        capture_results.append({
            "file": filename,
            "sha256": digest,
            "scroll": scroll,
            "clip": args["clip"],
            "pixels_checked": pixels_checked,
            "top_patches": patch_details,
            "bottom_quadrants": quadrant_details,
        })
    require(len(set(digest_list)) == 1, "calibration captures differ across scroll positions", errors)
    return {"errors": errors, "captures": capture_results, "same_digest": len(set(digest_list)) == 1}



def main():
    calibration = calibrate(ROOT)
    errors = list(calibration['errors'])
    paths = sorted(ROOT.glob('app-mobile-*.json'))
    require(len(paths) == 48, 'expected 48 mobile groups', errors)
    groups = []
    expected = {f'app-mobile-{w}-{page}-{theme}-{i}.json' for w in (320,375,390) for page in ('chat','admin') for theme in ('light','dark') for i in range(1,5)}
    require({p.name for p in paths} == expected, 'mobile matrix identities differ', errors)
    for path in paths:
        record = json.loads(path.read_text())
        err, leaves, count = verify_record(record,path.name,ROOT,sha_file(MEASURE_SOURCE))
        match = re.fullmatch(r'app-mobile-(320|375|390)-(chat|admin)-(light|dark)-([1-4])\.json',path.name)
        require(record['viewport']['width'] == int(match[1]), 'width mismatch: '+path.name,err)
        require(record['url'] == 'https://hasi.metaneutrons.cc/'+('admin' if match[2]=='admin' else ''), 'route mismatch: '+path.name,err)
        groups.append({'file':path.name,'capture_errors':err,'capture_valid':not err,'leaves':leaves,'images':count,'contrast_pass':not err and bool(leaves) and all(l['pass'] for l in leaves)})
    original = json.loads(paths[0].read_text())
    bad = copy.deepcopy(original)
    for leaf in bad['leaves']: leaf['color']=leaf['fill']='rgb(0, 0, 0)'
    for leaf in bad['restored']['leaves']: leaf['color']=leaf['fill']='rgb(0, 0, 0)'
    bad_errors,bad_leaves,_ = verify_record(bad,paths[0].name,ROOT,sha_file(MEASURE_SOURCE))
    low_contrast_rejected = not bad_errors and bool(bad_leaves) and not all(l['pass'] for l in bad_leaves)
    require(low_contrast_rejected,'coherent low-contrast counterprobe not rejected',errors)
    bad_font=copy.deepcopy(original);bad_font['leaves'][0]['threshold']=3
    bad_font['restored']['leaves'][0]['threshold']=3
    font_errors,_,_=verify_record(bad_font,paths[0].name,ROOT,sha_file(MEASURE_SOURCE))
    require(bool(font_errors),'font threshold counterprobe not rejected',errors)
    bad_geometry=copy.deepcopy(original);bad_geometry['imageChecks'][0]['after']['scroll']['y']+=1
    geometry_errors,_,_=verify_record(bad_geometry,paths[0].name,ROOT,sha_file(MEASURE_SOURCE))
    require(bool(geometry_errors),'geometry counterprobe not rejected',errors)
    result={'calibration':calibration,'errors':errors,'groups':groups,'group_count':len(groups),'image_count':sum(g['images'] for g in groups),'leaf_count':sum(len(g['leaves']) for g in groups),'lowest_ratio':min(l['profile_p3']['minimum_quantization_lower_bound'] for g in groups for l in g['leaves']),'counterprobes':{'coherent_black_foreground_rejected':low_contrast_rejected,'font_threshold_rejected':bool(font_errors),'per_image_geometry_rejected':bool(geometry_errors)},'pass':not errors and all(g['contrast_pass'] for g in groups)}
    (ROOT/'mobile-nav-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('groups','calibration')}))
    raise SystemExit(0 if result['pass'] else 1)

if __name__ == '__main__': main()
