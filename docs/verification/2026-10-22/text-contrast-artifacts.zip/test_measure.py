import json, tempfile, unittest
from pathlib import Path
from PIL import Image
from measure import analyze, contrast_ratio

class MeasurementTests(unittest.TestCase):
    def setUp(self): self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()
    def png(self, name, color, size=(1, 1)):
        Image.new("RGB", size, color).save(self.root / name, format="PNG")
    def run_case(self, normal, hidden, fg, *, unsupported=None, clip=(1, 1)):
        self.png("normal.png", normal); self.png("hidden.png", hidden, clip)
        data = {"viewport":{"width":1,"height":1},"normalImage":"normal.png","items":[{"id":"x","hiddenImage":"hidden.png","clip":{"left":0,"top":0,"width":1,"height":1},"rects":[{"left":0,"top":0,"right":1,"bottom":1}],"foregroundRGBA":fg,"threshold":4.5,"unsupportedFeatures":unsupported or []}]}
        p = self.root / "manifest.json"; p.write_text(json.dumps(data)); return analyze(p)["items"][0]
    def test_black_white_is_bounded_pass_near_21(self):
        r = self.run_case((0,0,0),(255,255,255),[0,0,0,1]); self.assertEqual(r["status"],"bounded-pass"); self.assertEqual(r["nominalMinimum"],21)
    def test_888_white_is_bounded_fail(self):
        c = round(136); r = self.run_case((c,c,c),(255,255,255),[136/255]*3+[1]); self.assertEqual(r["status"],"bounded-fail"); self.assertLess(r["minUpperBound"],4.5)
    def test_no_difference_is_unresolved(self):
        r = self.run_case((255,255,255),(255,255,255),[0,0,0,1]); self.assertEqual(r["matchedPixels"],0); self.assertEqual(r["status"],"unresolved")
    def test_wrong_clip_dimensions_refused(self):
        with self.assertRaisesRegex(ValueError,"hidden PNG dimensions"):
            self.run_case((0,0,0),(255,255,255),[0,0,0,1],clip=(2,1))
    def test_normal_dimensions_refused(self):
        self.png("normal.png", (0,0,0), (2,1)); self.png("hidden.png", (255,255,255))
        p = self.root / "manifest.json"; p.write_text(json.dumps({"viewport":{"width":1,"height":1},"normalImage":"normal.png","items":[]}))
        with self.assertRaisesRegex(ValueError,"normal PNG dimensions"): analyze(p)
    def test_alpha_foreground_composite(self):
        r = self.run_case((128,0,0),(0,0,0),[1,0,0,0.5]); self.assertAlmostEqual(r["nominalMinimum"], 1.908, places=2)
    def test_unsupported_is_not_measured(self):
        r = self.run_case((0,0,0),(255,255,255),[0,0,0,1],unsupported=["filter"]); self.assertEqual(r["status"],"unsupported")
    def test_exact_wcag_gray_boundary(self):
        self.assertLess(contrast_ratio([119/255]*3,[1,1,1]),4.5); self.assertGreater(contrast_ratio([118/255]*3,[1,1,1]),4.5)

if __name__ == "__main__": unittest.main()
