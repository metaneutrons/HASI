#!/usr/bin/env python3
"""DPR-1 screenshot contrast bounds for text over the documented HASI body radial."""
import json, math, sys
from pathlib import Path
from PIL import Image

RADIAL = (225 / 255, 176 / 255, 144 / 255)

def _values(v, n, name):
    if not isinstance(v, list) or len(v) != n or any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) or not 0 <= x <= 1 for x in v):
        raise ValueError(f"{name} must contain {n} numbers in [0,1]")
    return [float(x) for x in v]

def _luminance(rgb):
    linear = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb]
    return sum(w * c for w, c in zip((0.2126, 0.7152, 0.0722), linear))

def contrast_ratio(fg, bg):
    a, b = _luminance(fg), _luminance(bg)
    return (max(a, b) + 0.05) / (min(a, b) + 0.05)

def _lum_bounds(channels):
    return (_luminance([lo for lo, _ in channels]), _luminance([hi for _, hi in channels]))

def _ratio_bounds(fg, bg):
    fl, fh = fg; bl, bh = bg
    if fl <= bh and bl <= fh:
        upper = max((fh + 0.05) / (bl + 0.05), (bh + 0.05) / (fl + 0.05))
        return 1.0, upper
    if fh < bl:
        return (bl + 0.05) / (fh + 0.05), (bh + 0.05) / (fl + 0.05)
    return (fl + 0.05) / (bh + 0.05), (fh + 0.05) / (bl + 0.05)

def _image(path):
    with Image.open(path) as im:
        if im.format != "PNG": raise ValueError(f"expected PNG: {path}")
        rgba = im.convert("RGBA")
        if rgba.getchannel("A").getextrema() != (255, 255): raise ValueError(f"PNG must be fully opaque: {path}")
        return rgba.convert("RGB")

def _local_path(base, value, name):
    if not isinstance(value, str) or Path(value).is_absolute(): raise ValueError(f"{name} must be a relative path")
    path = (base / value).resolve()
    try: path.relative_to(base.resolve())
    except ValueError as exc: raise ValueError(f"{name} escapes manifest directory") from exc
    return path

def _item(item, base, normal, viewport):
    ident = item.get("id")
    unsupported = item.get("unsupportedFeatures")
    if not isinstance(ident, str) or not isinstance(unsupported, list) or any(not isinstance(x, str) for x in unsupported):
        raise ValueError("each item needs string id and unsupportedFeatures list")
    if unsupported: return {"id": ident, "status": "unsupported", "unsupportedFeatures": unsupported}
    clip = item.get("clip")
    if not isinstance(clip, dict): raise ValueError(f"{ident}: clip required")
    left, top, width, height = (clip.get(k) for k in ("left", "top", "width", "height"))
    if any(type(x) is not int for x in (left, top, width, height)) or left < 0 or top < 0 or width < 1 or height < 1 or left + width > viewport[0] or top + height > viewport[1]:
        raise ValueError(f"{ident}: clip must be integer CSS pixels inside viewport")
    hidden = _image(_local_path(base, item.get("hiddenImage"), "hiddenImage"))
    if hidden.size != (width, height): raise ValueError(f"{ident}: hidden PNG dimensions must equal clip dimensions")
    fg = _values(item.get("foregroundRGBA"), 4, f"{ident} foregroundRGBA")
    threshold = item.get("threshold")
    if threshold not in (3, 3.0, 4.5): raise ValueError(f"{ident}: threshold must be 3 or 4.5")
    rects = item.get("rects")
    if not isinstance(rects, list): raise ValueError(f"{ident}: rects must be a list")
    boxes = []
    for rect in rects:
        if not isinstance(rect, dict): raise ValueError(f"{ident}: invalid text rect")
        box = [rect.get(k) for k in ("left", "top", "right", "bottom")]
        if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in box) or box[2] <= box[0] or box[3] <= box[1]:
            raise ValueError(f"{ident}: text rect must have finite positive bounds")
        boxes.append(box)
    source = normal.load(); bg_pixels = hidden.load(); fg_alpha = fg[3]
    nominal, lowers, uppers, matched = [], [], [], 0
    for y in range(height):
        for x in range(width):
            cx, cy = left + x + 0.5, top + y + 0.5
            if not any(l <= cx < r and t <= cy < b for l, t, r, b in boxes): continue
            actual = source[left + x, top + y]; backdrop = bg_pixels[x, y]
            if max(abs(actual[i] - backdrop[i]) for i in range(3)) < 8: continue
            matched += 1
            bg = [c / 255 for c in backdrop]
            composed = [fg[i] * fg_alpha + bg[i] * (1 - fg_alpha) for i in range(3)]
            nominal.append(contrast_ratio(composed, bg))
            bg_channels = [(max(0, c - 1) / 255, min(255, c + 1) / 255) for c in backdrop]
            bg_lum = _lum_bounds(bg_channels)
            fg_channels = [(fg[i] * fg_alpha + lo * (1 - fg_alpha), fg[i] * fg_alpha + hi * (1 - fg_alpha)) for i, (lo, hi) in enumerate(bg_channels)]
            lo, hi = _ratio_bounds(_lum_bounds(fg_channels), bg_lum)
            lowers.append(lo); uppers.append(hi)
    lower = min(lowers) if lowers else None
    upper = min(uppers) if uppers else None
    status = "unresolved" if not matched or lower < threshold <= upper else "bounded-pass" if lower >= threshold else "bounded-fail" if upper < threshold else "unresolved"
    return {"id": ident, "status": status, "matchedPixels": matched, "nominalMinimum": min(nominal) if nominal else None, "minLowerBound": lower, "minUpperBound": upper}

def analyze(manifest_path):
    path = Path(manifest_path).resolve(); base = path.parent
    data = json.loads(path.read_text(encoding="utf-8")); view = data.get("viewport", {})
    w, h = view.get("width"), view.get("height")
    if type(w) is not int or type(h) is not int or w < 1 or h < 1: raise ValueError("viewport width/height must be positive integers")
    normal = _image(_local_path(base, data.get("normalImage"), "normalImage"))
    if normal.size != (w, h): raise ValueError("normal PNG dimensions must equal viewport dimensions (DPR 1)")
    items = data.get("items")
    if not isinstance(items, list): raise ValueError("items must be a list")
    return {"viewport": view, "items": [_item(item, base, normal, (w, h)) for item in items]}

def main():
    try: print(json.dumps(analyze(sys.argv[1]), indent=2))
    except (IndexError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"measurement refused: {exc}", file=sys.stderr); return 2
    return 0

if __name__ == "__main__": raise SystemExit(main())
