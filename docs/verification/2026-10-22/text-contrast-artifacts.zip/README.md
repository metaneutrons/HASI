# Bounded text contrast observations

These are synthetic localhost screenshots/manifests, not an application package or an accessibility approval. The measurement helper is an internal verification artifact and is not application runtime code. Requires Python3 and Pillow (observed Pillow12.3.0).

Run `python3 -m unittest test_measure.py` (eight tests) and `python3 measure.py controls.json`; known black-on-white passes, known gray/alpha controls fail. Run `python3 measure.py <manifest>.json` for each measured state. Bounded outcomes are in the result JSON; a command exit0 means the measurement ran, not that every target passes. Unsupported features and absent glyph matches remain unqualified.

Normal images contain the actual viewport at DPR1. The paired target image was captured after temporarily making only the selected text foreground transparent; its boxes/backgrounds/layout remained. CSS foreground RGBA and text-range rectangles are in the manifest. Foreground alpha is composed over the measured background. Normal-vs-hidden pixels differing by at least8 channels identify rendered glyph pixels within those ranges. WCAG sRGB luminance uses CSS foreground, not antialias pixel darkness; background quantization is bounded by one channel step. Normal text requires4.5; large text requires3.

Root reviewed source/DOM: flat text colors, no foreground filter/blend/group opacity accepted. Backdrop filters are included in captured backgrounds. This is sampled text contrast, not all non-text/focus/hover states, native AT, Dynamic Type or complete WCAG acceptance. The first corrected empty-bookings capture still had an ancestor entry-animation opacity and is explicitly unsupported; its stable retry is separate.
